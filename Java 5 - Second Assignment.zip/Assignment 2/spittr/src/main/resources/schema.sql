create table Spittle (
	id identity,
	message varchar(140) not null,
	created_at timestamp not null,
	latitude double,
	longitude double
);

create table Player (
	id identity,
	last_name varchar(30) unique not null,
	first_name varchar(30) not null,
	age INTEGER not null,
	country varchar(30) not null,
	spot varchar(20) not null,
);

create table Trainer (
	id identity,
	last_name varchar(30) unique not null,
	first_name varchar(30) not null,
	age INTEGER not null,
	teams varchar(30) not null,
);

create table Stats (
	id identity,
	last_name varchar(30) not null,
	goals INTEGER not null,
	bookings INTEGER not null
);

create table Spitter (
	id identity,
	username varchar(20) unique not null,
	password varchar(20) not null,
	first_name varchar(30) not null,
	last_name varchar(30) not null,
	email varchar(30) not null
);