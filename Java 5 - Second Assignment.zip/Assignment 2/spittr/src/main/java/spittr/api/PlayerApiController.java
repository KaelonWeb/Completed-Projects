package spittr.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;
import spittr.Player;
import spittr.data.PlayerNotFoundException;
import spittr.data.PlayerNotFoundException2;
import spittr.data.PlayerRepository;

import java.net.URI;

/**
 * Created by Andrew on 25/08/2015.
 */

@RestController
@RequestMapping("/playerapi")
public class PlayerApiController {
    private static final String MAX_LONG_AS_STRING = "9223372036854775807";

    private PlayerRepository playerRepository;

    @Autowired
    public PlayerApiController(PlayerRepository playerRepository) {
        this.playerRepository = playerRepository;
    }

    @RequestMapping(value="/{lastname}", method=RequestMethod.GET, produces = "application/json")
    public Player showPlayerProfile(@PathVariable String lastname) {
        Player player = playerRepository.findByLastName(lastname);
        System.out.println(player.getFirstName() +" " + player.getLastName() + " " + player.getAge() + " " + player.getCountryOfBirth() + " " + player.getPosition());
        return player;
    }

    @RequestMapping(method=RequestMethod.POST, consumes="application/json")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Player> processRegistration(@RequestBody Player player, UriComponentsBuilder ucb) {
        System.out.println();
        Player saved = playerRepository.save(player);

        HttpHeaders headers = new HttpHeaders();
        URI locationUri = ucb.path("/player/")
                .path(String.valueOf(saved.getLastName()))
                .build()
                .toUri();
        headers.setLocation(locationUri);
        ResponseEntity<Player> responseEntity = new ResponseEntity<Player>(saved, headers, HttpStatus.CREATED);
        return responseEntity;
    }


    @ExceptionHandler(PlayerNotFoundException2.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public @ResponseBody Error spittleNotFound(PlayerNotFoundException2 e) {
        String spittleId = e.getSpittlename();
        return new Error(4, "Player [" + spittleId + "] not found");
    }

    @ExceptionHandler(PlayerNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public @ResponseBody Error spittleNotFound(PlayerNotFoundException e) {
        long spittleId = e.getSpittleId();
        return new Error(4, "Player [" + spittleId + "] not found");
    }
}

