package spittr.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;
import spittr.Trainer;
import spittr.data.TrainerRepository;

import javax.validation.Valid;
import java.util.Locale;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@RequestMapping("/trainer")
public class TrainerController {

  private TrainerRepository spitterRepository;

  @Autowired
  public TrainerController(TrainerRepository spitterRepository) {
    this.spitterRepository = spitterRepository;
  }
  
  @RequestMapping(value="/register", method=GET)
  public String showRegistrationForm(Model model, Locale locale) {
    model.addAttribute("trainer",new Trainer());
    return "trainer";
  }
  
  @RequestMapping(value="/register", method=POST)
  public String processRegistration(
      @Valid Trainer spitter,
      Errors errors, Locale locale) {
    if (errors.hasErrors()) {
      return "trainer";
    }
    spitterRepository.display(spitter);
    return "trainerDisplay";
  }

  
}
