package spittr.web;

/**
 * Created by e_goch on 7/21/2015.
 */
public class RootConfig {

}
