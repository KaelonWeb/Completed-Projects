package spittr.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import spittr.Player;
import spittr.data.PlayerRepository;

import javax.validation.Valid;
import java.util.Locale;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

@Controller
@RequestMapping("/player")
public class PlayerController {
    private static final String MAX_LONG_AS_STRING = "9223372036854775807";
  private PlayerRepository spitterRepository;

  @Autowired
  public PlayerController(PlayerRepository spitterRepository) {
    this.spitterRepository = spitterRepository;
  }
  
  @RequestMapping(method=RequestMethod.GET)
  public String showRegistrationForm(Model model, Locale locale) {
    model.addAttribute("player",new Player());
    model.addAttribute(locale);
    return "playerForm";
  }

//    @RequestMapping(method= RequestMethod.GET)
//    public List<Player> spittles(
//            @RequestParam(value="max", defaultValue=MAX_LONG_AS_STRING) long max,
//            @RequestParam(value="count", defaultValue="20") int count) {
//        return spitterRepository.findPlayer(max, count);
//    }


  @RequestMapping(method=RequestMethod.POST)
  public String processRegistration(
      @Valid Player player,
      Errors errors) {
    if (errors.hasErrors()) {
      return "playerForm";
    }
    spitterRepository.save(player);
    //spitterRepository.display(player);
    return "redirect:/player/" + player.getLastName();
    //return "playerDisplay";
  }


  @RequestMapping(value="/{lastname}", method=GET)
  public String showPlayerProfile(@PathVariable String lastname, Model model) {
    Player player = spitterRepository.findByLastName(lastname);
    model.addAttribute(player);
    return "playerDisplay";
  }
}
/*
    @RequestMapping(value="/{lastname}", method=GET)
    public String showPlayerProfile(@PathVariable String lastname, Model model) {
        BasePlayer player = playerRepository.findByLastName(lastname);
        model.addAttribute(player);
        return "playerProfile";
    }*/