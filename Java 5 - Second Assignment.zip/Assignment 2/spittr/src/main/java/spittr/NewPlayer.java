package spittr;

/**
 * Created by Andrew on 14/08/2015.
 */
public interface NewPlayer {
}
