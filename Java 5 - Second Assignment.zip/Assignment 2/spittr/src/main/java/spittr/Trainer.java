package spittr;

import org.springframework.stereotype.Component;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Arrays;

/**
 * Created by User on 2015-07-17.
 */
@Component
public class Trainer{

    @Size(min=1, max=30, message="firstName.size")
    @NotNull
    @Pattern(regexp = "^[a-zA-Z]+$", message="firstName.pattern")
    private String firstName;

    @Size(min=1, max=30, message="firstName.size")
    @NotNull
    @Pattern(regexp ="^[a-zA-Z]+$", message="lastName.pattern")
    private String lastName;
    @NotNull
    @Min(value = 40, message = "age.min")
    private int age;
    private String[] teams;
    private Currency annualSalary;
    //private double salary;

    public Trainer()
    {
        super();
    }

    //@Autowired
    public Trainer(String fname, String lname, int trainerage, String[] teams)
    {
        this.firstName = fname;
        this.lastName = lname;
        this.age = trainerage;
        this.teams = teams;
    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String[] getTeams() {
        return teams;
    }

    public void setTeams(String[] teams) {this.teams = teams;
    }


    public final class Currency
            extends Object
            implements Serializable
    {

    }

    public boolean isValid(Trainer trainer)
    {
        boolean check;
        if(trainer.firstName.matches("^[a-z\\sA-Z]+$"))
        {
            check=true;
        }
        else
        {
            System.out.println("Trainer First name is non alphanumeric");
            check=false;
        }
        if(trainer.lastName.matches("^[a-z\\sA-Z]+$"))
        {
            check=true;
        }
        else
        {
            System.out.println("Trainer Last name is non alphanumeric");
            check=false;
        }
        if(trainer.age>=40)
        {
            check=true;
        }
        else
        {
            System.out.println("Trainer Player is too young");
            check=false;
        }
        for(int i =0; i<trainer.getTeams().length;i++) {
            if(trainer.getTeams()[i].matches("^[a-z\\sA-Z]+$"))
            {
                check = true;
            }
            else
            {
                int j=i+1;
                System.out.println("Trainer's Team # " + j + " is invalid");
                check = false;
            }
        }
        return check;
    }

    @Override
    public String toString() {
        return "Trainer{" +
                "teams=" + Arrays.toString(teams) +
                '}';
    }
}

