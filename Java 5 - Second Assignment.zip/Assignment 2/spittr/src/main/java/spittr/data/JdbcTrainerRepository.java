package spittr.data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import spittr.Trainer;

import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
public class JdbcTrainerRepository implements TrainerRepository {

  private JdbcOperations jdbc;

  @Autowired
  public JdbcTrainerRepository(JdbcOperations jdbc) {
    this.jdbc = jdbc;
  }

    public Trainer display(Trainer trainer){
        return trainer;
    }

  public Trainer save(Trainer trainer) {
    jdbc.update(
            "insert into Player (first_name, last_name, age, teams)" +
                    " values (?, ?, ?, ?)",
            trainer.getFirstName(),
            trainer.getLastName(),
            trainer.getAge(),
            trainer.getTeams());
    //player.getStatistics());
    return trainer;
  }

  public Trainer findByLastName(String lastName) {
    Trainer trainer;
    trainer = jdbc.queryForObject(
            "select id, first_name, last_name, age, teams from Trainer where last_name=?",
            new TrainerRowMapper(),
            lastName);
    return trainer;
  }

  private static class TrainerRowMapper implements RowMapper<Trainer> {
    public Trainer mapRow(ResultSet rs, int rowNum) throws SQLException {
      return new Trainer(
              rs.getString("first_name"),
              rs.getString("last_name"),
              rs.getInt("age"),
              new String[]{rs.getString("teams")});
    }
  }

}
