package spittr.data;

/**
 * Created by Andrew on 28/08/2015.
 */
public class PlayerNotFoundException2  extends RuntimeException {
    private static final long serialVersionUID = 1L;

   // private long spittleId;
    private String spittlename;

    public PlayerNotFoundException2(String spittlename) {
        this.spittlename = spittlename;
    }

    public String getSpittlename() {
        return spittlename;
    }
}
