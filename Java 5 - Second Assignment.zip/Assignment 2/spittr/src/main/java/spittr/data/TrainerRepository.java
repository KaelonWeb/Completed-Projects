package spittr.data;

import spittr.Trainer;

public interface TrainerRepository {

     Trainer save(Trainer trainer);

    Trainer findByLastName(String lastname);

    Trainer display(Trainer trainer);
}
