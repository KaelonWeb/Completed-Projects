package spittr.data;

import spittr.Player;

public interface PlayerRepository {

    Player display(Player player);
    Player save(Player player);

    Player findByLastName(String lastname);



}
