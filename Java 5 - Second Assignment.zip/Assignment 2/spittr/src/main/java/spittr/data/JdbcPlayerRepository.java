package spittr.data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import spittr.Player;
import spittr.Stats;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class JdbcPlayerRepository implements PlayerRepository {

  private JdbcOperations jdbc;

  @Autowired
  public JdbcPlayerRepository(JdbcOperations jdbc) {
    this.jdbc = jdbc;
  }

  public Player display(Player player) {
    return player;
  }

  public Player save(Player player) {
    jdbc.update(
            "insert into Player (last_name,first_name, age, country, spot)" +
                    " values (?, ?, ?, ?, ?)",
            player.getLastName(),
            player.getFirstName(),
            player.getAge(),
            player.getCountryOfBirth(),
            player.getPosition());
            //player.getStatistics());
            jdbc.update(
                    "insert into Stats (last_name, goals, bookings)" +
                            " values (?, ?, ?)",
                    player.getLastName(),
                    player.getStatistics().getGoals(),
                    player.getStatistics().getBookings());
    return player;
  }

    public List<Player> findPlayer(long max, int count) {
        System.out.println("last");
        return jdbc.query(
                "select *" +
                        " from Player" +
                        " where last_name=?",
                new PlayerRowMapper2(), max);
    }

  public Player findByLastName(String lastName) {
    Player player;
    player = jdbc.queryForObject(
            "select id, last_name, first_name, age, country, spot from Player where last_name=?",
            new PlayerRowMapper(),
            lastName);
    Stats statistics;
    statistics = jdbc.queryForObject(
            "select id, last_name, goals, bookings from Stats where last_name=?",
            new StatisticsRowMapper(),
            lastName);
    player.setStatistics(statistics);
    return player;
  }

    public Player findLastName(String lastName) {
        //Player player;
        try{
            return jdbc.queryForObject(
                "select  last_name,first_name, age, country, spot" +
                        " from Player" +
                        " where last_name = ?",
                new PlayerRowMapper(), lastName);

        }catch (EmptyResultDataAccessException e) {
            throw new PlayerNotFoundException2(lastName);
        }
//               Stats statistics;
//        statistics = jdbc.queryForObject(
//                "select id, last_name, goals, bookings from Stats where last_name=?",
//                new StatisticsRowMapper(),
//                lastName);
//        player.setStatistics(statistics);
//        return player;
    }

    public Player findOne(long id) {
        try {
            return jdbc.queryForObject(
                    "select  last_name,first_name, age, country, spot" +
                            " from Player" +
                            " where id = ?",
                    new PlayerRowMapper2(), id);
        } catch (EmptyResultDataAccessException e) {
            throw new PlayerNotFoundException(id);
        }
    }

    private static class PlayerRowMapper2 implements RowMapper<Player> {
        public Player mapRow(ResultSet rs, int rowNum) throws SQLException {
            return new Player(
                    //rs.getLong("id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getInt("age"),
                    rs.getString("country"),
                    rs.getString("spot"));
        }
    }

  private static class PlayerRowMapper implements RowMapper<Player> {
    public Player mapRow(ResultSet rs, int rowNum) throws SQLException {
      return new Player(
              rs.getString("last_name"),
              rs.getString("first_name"),
              rs.getInt("age"),
              rs.getString("country"),
              rs.getString("spot"));
    }
  }

  private static class StatisticsRowMapper implements RowMapper<Stats> {
    public Stats mapRow(ResultSet rs, int rowNum) throws SQLException {
      return new Stats(
              rs.getInt("goals"),
              rs.getInt("bookings"));
    }
  }
}
