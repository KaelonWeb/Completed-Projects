package spittr;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Created by Andrew on 21/07/2015.
 */
public class Teams implements FirstTeam
{
    @NotNull
    @Size(min=1)
    private String teamName;
    @NotNull
    @Min(1950)
    private int foundationyear;
    private Player testPlayer;
    private Player testPlayer2;
    private Trainer trainer;
    private Trainer trainer2;



    public Teams(Player testPlayer,Player testPlayer2, Trainer testTrainer, Trainer testTrainer2)
    {
        this.testPlayer=testPlayer;
        this.testPlayer2=testPlayer2;
        this.trainer=testTrainer;
        this.trainer2=testTrainer2;
    }

    public Trainer getTestTrainer() { return trainer; }

    public Trainer getTestTrainer2() { return trainer2; }

    public String getTeamName() {
        return teamName;
    }

    public Player getTestPlayer() {
        return testPlayer;
    }

    public Player getTestPlayer2() {
        return testPlayer2;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public int getFoundationyear() {
        return foundationyear;
    }

    public void setFoundationyear(int foundationyear) {
        this.foundationyear = foundationyear;
    }
}
