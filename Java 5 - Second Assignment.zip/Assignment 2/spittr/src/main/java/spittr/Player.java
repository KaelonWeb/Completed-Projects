package spittr;


import org.springframework.stereotype.Component;

import javax.validation.constraints.*;
import java.io.Serializable;

/**
 * Created by User on 2015-07-17.
 */
@Component
public class Player implements NewPlayer{
    public static final String GOALKEEPER = "Goalkeeper";
    public static final String DEFENDER = "Defender";
    public static final String MIDFIELDER = "Midfielder";
    public static final String FORWARD = "Forward";

    private long id;

    @NotNull
   //@Pattern([a-zA-Z])
    @Size(min=1, max=40, message="{firstName.Size}")
    @Pattern(regexp = "^[a-zA-Z]+$", message="{firstName.pattern}")
    private String firstName="";
//    "[A-Za-z"
    @Size(min=1, max=40, message="{lastName.size}")
    @NotNull
    @Pattern(regexp = "^[a-zA-Z]+$", message="{lastName.pattern}")
    private String lastName="";
    @NotNull
    @Min(value = 20, message = "{age.min}")
    @Max(value = 23, message = "{age.max}")
    private int age;
    @NotNull
    @Size(min=1, max=40, message="{countryOfBirth.size}")
    @Pattern(regexp = "^[a-zA-Z]+$", message="{countryOfBirth.pattern}")
    private String countryOfBirth="";
    @NotNull
    private String position;
    private Currency annualSalary;
    private Stats statistics = new Stats(0,0);

public Player()
{
}
    public Player( String lname,String fname, int age, String countryBirth,String position)
    {
        this.firstName = fname;
        this.lastName = lname;
        this.age = age;
        this.countryOfBirth = countryBirth;
        this.position = position;
    }

    public Player( String lname,String fname, int age, String countryBirth,String position, Stats statistics)
    {
        this.firstName = fname;
        this.lastName = lname;
        this.age = age;
        this.countryOfBirth = countryBirth;
        this.position = position;
        this.statistics = statistics;

    }

    public long getId() {
        return id;
    }

    public int getAge() {
        return age;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getCountryOfBirth() {
        return countryOfBirth;
    }

    public String getPosition() {
        return position;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setCountryOfBirth(String countryOfBirth) {
        this.countryOfBirth = countryOfBirth;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public Stats getStatistics() {
        return statistics;
    }

    public void setStatistics(Stats statistics) {
        this.statistics = statistics;
    }

    public final class Currency
            extends Object
            implements Serializable
    {

    }

    public boolean isValid(Player player)
    {
        boolean check;
        if(player.firstName.matches("^[a-z\\sA-Z]+$"))
        {
            check=true;
        }
        else
        {
            System.out.println("Player First name is non alphanumeric");
            check=false;
        }
        if(player.lastName.matches("^[a-z\\sA-Z]+$"))
        {
            check=true;
        }
        else
        {
            System.out.println("Player Last name is non alphanumeric");
            check=false;
        }
        if(player.age>=20 && player.age<=23)
        {
            check=true;
        }
        else
        {
            System.out.println("Player is too young or old");
            check=false;
        }
        if(player.countryOfBirth.matches("^[a-z\\sA-Z]+$"))
        {
            check=true;
        }
        else
        {
            System.out.println("Player Country of Birth is non alphanumeric");
            check=false;
        }
        if(player.position == "Goalkeeper" || player.position == "Defender" || player.position == "Midfielder" || player.position == "Forward")
        {
            check=true;
        }
        else
        {
            System.out.println("Player Position is invalid");
            check=false;
        }
        return check;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Player player = (Player) o;

        if (age != player.age) return false;
        if (!firstName.equals(player.firstName)) return false;
        if (!lastName.equals(player.lastName)) return false;
        if (!countryOfBirth.equals(player.countryOfBirth)) return false;
        return position.equals(player.position);

    }

    @Override
    public int hashCode() {
        int result = firstName.hashCode();
        result = 31 * result + lastName.hashCode();
        result = 31 * result + age;
        result = 31 * result + countryOfBirth.hashCode();
        result = 31 * result + position.hashCode();
        return result;
    }
}
