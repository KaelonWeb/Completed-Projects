package spittr;

/**
 * Created by Andrew on 26/07/2015.
 */
public interface FirstTeam
{
    Player getTestPlayer();
    Player getTestPlayer2();
    Trainer getTestTrainer();
    Trainer getTestTrainer2();

}
