package spittr;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * Created by Andrew on 27/07/2015.
 */
public class Stats
{
    @NotNull
    @Min(value = 0, message = "{goals.min}")
    private int goals = 0;
    @NotNull
    @Min(value = 0, message = "{bookings.min}")
    private int bookings = 0;

    public Stats(int goals, int bookings) {
        this.goals = goals;
        this.bookings = bookings;
    }

    public int getGoals() {
        return goals;
    }

    public void setGoals(int goals) {
        this.goals = goals;
    }

    public int getBookings() {
        return bookings;
    }

    public void setBookings(int bookings) {
        this.bookings = bookings;
    }
}
