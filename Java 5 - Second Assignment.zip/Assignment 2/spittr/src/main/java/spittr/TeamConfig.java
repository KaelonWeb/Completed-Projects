package spittr;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * Created by User on 2015-07-19.
 */
@Configuration
@ComponentScan(basePackages = "com.spittr")
public class TeamConfig {

    @Bean
    @Profile("Team")
    Player getTestPlayer()
    {
        return new Player("Albie", "Sanders", 22, "United States", Player.FORWARD, getPlayerStats());
    }

    @Bean
    @Profile("Team")
    Player getTestPlayer2()
    {
        return new Player("123", "456", 44, "3424", "Benchwarmer", getPlayerStats());
    }

    @Bean
    @Profile("Team")
    Trainer getTestTrainer()
    {
        return new Trainer("Bobby", "Brown", 40, new String[]{"Team A", "Team B"});
    }

    @Bean
    @Profile("Team")
    Trainer getTestTrainer2()
    {
        return new Trainer("123", "4445", 22, new String[]{"Team C", "2222"});
    }

    @Bean
    @Profile("Team")
    Teams getTestTeam()
    {
        return new Teams(getTestPlayer(),getTestPlayer2(),getTestTrainer(),getTestTrainer2());
    }

    @Bean
    @Profile("Team")
    Stats getPlayerStats()
    {
        return new Stats(0, 0);
    }
}
