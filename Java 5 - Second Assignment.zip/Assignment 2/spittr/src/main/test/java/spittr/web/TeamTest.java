package spittr.web;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import spittr.Player;
import spittr.TeamConfig;
import spittr.Teams;
import spittr.Trainer;

import static org.junit.Assert.assertNotNull;

/**
 * Created by User on 2015-07-19.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = TeamConfig.class)
@ActiveProfiles("Team")

public class TeamTest {

    @Autowired
    public Teams firstTeam;

    @Test
    public void assertTeam_HasTestPlayer() {
        assertNotNull(firstTeam.getTestPlayer());
    }

    @Test
    public void assertTeam_HasTestPlayer2() {
        assertNotNull(firstTeam.getTestPlayer2());
    }

    @Test
    public void isPlayerValid() {
        Player p = new Player();
        p.isValid(firstTeam.getTestPlayer());
    }

    @Test
    public void isPlayerInvalid() {
        Player p = new Player();
        p.isValid(firstTeam.getTestPlayer2());
    }

    @Test
    public void isTrainerValid() {
        Trainer t = new Trainer();
        t.isValid(firstTeam.getTestTrainer());
    }

    @Test
    public void isTrainerInvalid() {
        Trainer t = new Trainer();
        t.isValid(firstTeam.getTestTrainer2());
    }

    @Test
    public void assertTeam_HasTestTrainer() {
        assertNotNull(firstTeam.getTestTrainer());
    }

    @Test
    public void assertTeam_HasTestTrainer2() {
        assertNotNull(firstTeam.getTestTrainer2());
    }

}
