package spittr.web;

import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.test.web.servlet.MockMvc;
import spittr.Trainer;
import spittr.data.TrainerRepository;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

/**
 * Created by Andrew on 15/08/2015.
 */
public class TrainerControllerTest extends TestCase {

    @Test
    public void testShowRegistrationForm() throws Exception {
        TrainerRepository mockRepository = mock(TrainerRepository.class);
        TrainerController controller = new TrainerController(mockRepository);
        MockMvc mockMvc = standaloneSetup(controller).build();
        mockMvc.perform(get("/trainer/register"))
                .andExpect(view().name("trainer"));
    }

    @Test
    public void testProcessRegistration() throws Exception {
        TrainerRepository mockRepository = mock(TrainerRepository.class);
        Trainer unsaved = new Trainer("Bobby", "Brown", 40, new String[]{"Team A", "Team B"});
        Trainer saved = new Trainer("Bobby", "Brown", 40, new String[]{"Team A", "Team B"});
        when(mockRepository.display(unsaved)).thenReturn(saved);

        TrainerController controller = new TrainerController(mockRepository);
        MockMvc mockMvc = standaloneSetup(controller).build();

        mockMvc.perform(post("/trainer/register")
                .param("firstName", "Bobby")
                .param("lastName", "Brown")
                .param("age", "40")
                .param("teams", "Team A", "Team B"))
                .andExpect(view().name("trainerDisplay"));
    }

}