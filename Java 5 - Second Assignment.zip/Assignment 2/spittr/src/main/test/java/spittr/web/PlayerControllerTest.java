package spittr.web;

import org.junit.Test;
import org.springframework.test.web.servlet.MockMvc;
import spittr.Player;
import spittr.Stats;
import spittr.data.PlayerRepository;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

/**
 * Created by Andrew on 15/08/2015.
 */
public class PlayerControllerTest {

    @Test
    public void testShowRegistrationForm() throws Exception {
        PlayerRepository mockRepository = mock(PlayerRepository.class);
        PlayerController controller = new PlayerController(mockRepository);
        MockMvc mockMvc = standaloneSetup(controller).build();
        mockMvc.perform(get("/player"))
                .andExpect(view().name("playerForm"));
    }

    @Test
    public void testProcessRegistration() throws Exception {
        PlayerRepository mockRepository = mock(PlayerRepository.class);
        Stats statistics = new Stats(4,4);
        Player unsaved = new Player( "Sanders","Albie", 22, "United States", "Forward", statistics);
        Player saved = new Player( "Sanders","Albie", 22, "United States", "Forward", statistics);
        when(mockRepository.save(unsaved)).thenReturn(saved);

        PlayerController controller = new PlayerController(mockRepository);
        MockMvc mockMvc = standaloneSetup(controller).build();

        mockMvc.perform(post("/player")
                .param("lastName", "Sanders")
                .param("firstName", "Albie")
                .param("age", "22")
                .param("country", "United States")
                .param("position", "Forward")
                .param("stats.goals", "4")
                .param("stats.bookings", "4"))
                .andExpect(redirectedUrl("/player/Sanders"));
        verify(mockRepository, atLeastOnce()).save(unsaved);
    }

    @Test
    public void testShowPlayerProfile() throws Exception {
        PlayerRepository mockRepository = mock(PlayerRepository.class);
        Player unsaved = new Player( "Sanders","Albie", 22, "United States", "Forward");
        Player saved = new Player( "Sanders","Albie", 22, "United States", "Forward");
        when(mockRepository.display(unsaved)).thenReturn(saved);

        PlayerController controller = new PlayerController(mockRepository);
        MockMvc mockMvc = standaloneSetup(controller).build();

        mockMvc.perform(post("/player")
                .param("firstName", "Albie")
                .param("lastName", "Sanders")
                .param("age", "22")
                .param("country", "United States")
                .param("position", "Forward")
                .param("stats.goals", "4")
                .param("stats.bookings", "4"))
                .andExpect(redirectedUrl("/playerapi/Sanders"));
    }
}