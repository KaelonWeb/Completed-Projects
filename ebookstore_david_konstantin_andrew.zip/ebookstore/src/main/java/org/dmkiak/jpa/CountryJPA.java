package org.dmkiak.jpa;

import com.dmkiak.beans.Country;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import javax.annotation.Resource;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;

/**
 * Bean to manage Country Entity
 *
 * @author David Maignan <davidmaignan@gmail.com>
 *
 */
@Named
@RequestScoped
public class CountryJPA implements Serializable {
    @Resource
    private UserTransaction userTransaction;
    
    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;
    
    public List<Country> getAll() throws SQLException {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Country> cq = cb.createQuery(Country.class);
        Root<Country> fish = cq.from(Country.class);
        cq.select(fish);
        TypedQuery<Country> query = entityManager.createQuery(cq);
        
        return query.getResultList();
    }
}