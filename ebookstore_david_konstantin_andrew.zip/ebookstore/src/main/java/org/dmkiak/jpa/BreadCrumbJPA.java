package org.dmkiak.jpa;

import com.dmkiak.navigation.BreadCrumb;
import java.io.Serializable;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import org.apache.log4j.Logger;

/**
 * BreadCrumb Bean
 *
 * @author David Maignan
 *
 */
@Named
@RequestScoped
public class BreadCrumbJPA implements Serializable {
    
    private static final Logger logger = Logger.getLogger(BreadCrumbJPA.class);
    
    @Inject
    BreadCrumb breadCrumb;
    
    public BreadCrumb getAll() {
        return breadCrumb;
    }
}