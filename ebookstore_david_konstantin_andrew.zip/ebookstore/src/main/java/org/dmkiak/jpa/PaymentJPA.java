package org.dmkiak.jpa;

import com.dmkiak.beans.Inventory;
import com.dmkiak.beans.Invoice;
import com.dmkiak.beans.LineItem;
import com.dmkiak.beans.User;
import com.dmkiak.cart.Cart;
import com.dmkiak.controller.InvoiceJpaController;
import com.dmkiak.controller.LineItemJpaController;
import com.dmkiak.session.SessionManager;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;
import org.apache.log4j.Logger;

/**
 * Payment JPA
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@RequestScoped
@Named("paymentJPA")
public class PaymentJPA {

    private String creditCardType;
    private String creditCardNumber;
    private String fullName;
    private int expiryMonth;
    private int expiryYear;

    private Logger logger = Logger.getLogger(UserJPA.class);

    @Resource
    private UserTransaction userTransaction;

    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;

    private FacesContext context;
    
    @Inject
    SessionManager sessionManager;
    
    @Inject
    InvoiceJpaController ijc;
    
    @Inject
    LineItemJpaController lijc;

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getCreditCardType() {
        return creditCardType;
    }

    public void setCreditCardType(String creditCardType) {
        this.creditCardType = creditCardType;
    }

    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(String creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public int getExpiryMonth() {
        return expiryMonth;
    }

    public void setExpiryMonth(int expiryMonth) {
        this.expiryMonth = expiryMonth;
    }

    public int getExpiryYear() {
        return expiryYear;
    }

    public void setExpiryYear(int expiryYear) {
        this.expiryYear = expiryYear;
    }

    public String save() {
        String returnString = "orderCompleted?faces-redirect=true";

        try {
            int userId = this.getUser().getId();
        
            Query query = entityManager.createNamedQuery("User.findById");
            query.setParameter("id", userId);
            User user = (User)query.getSingleResult();
            
            Cart cart = getCart();
            
            Invoice invoice = new Invoice();
            invoice.setPst(cart.getPstTotal());
            invoice.setGst(cart.getGstTotal());
            invoice.setTotalGross(cart.getTotal());
            invoice.setTotalNet(cart.getGrandTotal());
            invoice.setUserId(user);
           
            ijc.create(invoice);
            
            ArrayList<LineItem> lineItemList = getLineItemList();
            
            invoice.setLineItemCollection(lineItemList);
            
            for (LineItem lineItem : lineItemList) {
                lineItem.setInvoiceId(invoice);
                lijc.create(lineItem);
            }
            
            //Empty cart
            sessionManager.emptyCart();
               
        } catch (Exception ex) {
            logger.error(ex);
            returnString = "payment";
        }
        
        return returnString;
    }
    
    public List<String> getMonthList(){
        ArrayList<String> list =  new ArrayList<>();
        
        list.add("January");
        list.add("February");
        list.add("March");
        list.add("April");
        list.add("May");
        list.add("June");
        list.add("July");
        list.add("August");
        list.add("September");
        list.add("October");
        list.add("November");
        list.add("December");
        
        return list;
    }
    
    public List<String> getCreditCardList(){
        ArrayList<String> list =  new ArrayList<>();
        list.add("MasterCard");
        list.add("Visa");
        list.add("American Express");
        
        return list;
    }
    
    public List<Integer> getYearList(){
        ArrayList<Integer> list =  new ArrayList<>();
        
        for (int i = 2015; i <= 2020; i+=1) {
            list.add(i);
        }
        
        return list;
    }

    private Cart getCart() {
        Cart cart = null;

        context = FacesContext.getCurrentInstance();

        if (context.getExternalContext().getSessionMap().get("cart") instanceof Cart) {
            cart = (Cart) context.getExternalContext().getSessionMap().get("cart");
        }

        return cart;
    }
    
    private ArrayList<LineItem> getLineItemList(){
        ArrayList<LineItem> list = new ArrayList<>();
        
        for (Inventory inventory : getCart().getList()) {
            LineItem lineItem = new LineItem();
            lineItem.setIsbn(inventory);
            lineItem.setPrice(inventory.getListPrice());
            lineItem.setQuantity(1);
            list.add(lineItem);
        }
        
        return list;
    }

    private User getUser() {
        User user = null;

        context = FacesContext.getCurrentInstance();

        if (context.getExternalContext().getSessionMap().get("user") instanceof User) {
            user = (User) context.getExternalContext().getSessionMap().get("user");
        }

        return user;
    }
}
