package org.dmkiak.jpa;

import com.dmkiak.beans.Genre;
import com.dmkiak.beans.Inventory;
import com.dmkiak.beans.Invoice;
import com.dmkiak.beans.Review;
import com.dmkiak.controller.ReviewJpaController;
import com.dmkiak.cookie.CookieManager;
import com.dmkiak.session.SessionManager;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.servlet.http.Cookie;
import javax.transaction.UserTransaction;

/**
 * Inventory JPA Bean
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class InventoryJPA implements Serializable {
    //private Logger //logger = Logger.getLogger(InventoryJPA.class);

    private int pageSize = 10;
    private String category;

    private String review;
    private String isbn;
    private int rating = 3;
    private Review newReview;

    private String searchField;

    @Inject
    CookieManager cookieManager;

    @Inject
    SessionManager sessionManager;

    @Inject
    ReviewJpaController rjc;

    @Resource
    private UserTransaction userTransaction;

    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;

    public String getSearchField() {
        return searchField;
    }

    public void setSearchField(String searchField) {
        this.searchField = searchField;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    /**
     * Process review submission
     */
    public void processReview() {
        Review newReview = new Review();
        newReview.setIsbn(this.getByIsbn(this.getIsbn()));
        newReview.setUserId(sessionManager.getUser());
        newReview.setReview(this.getReview().getBytes());
        newReview.setApprovalStatus(false);
        newReview.setRating(this.getRating());

        try {
            rjc.create(newReview);
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(InventoryJPA.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    /**
     * Get all inventories
     *
     * @return
     * @throws SQLException
     */
    public List<Inventory> getAll() throws SQLException {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Inventory> cq = cb.createQuery(Inventory.class);
        Root<Inventory> fish = cq.from(Inventory.class);
        cq.select(fish);
        TypedQuery<Inventory> query = entityManager.createQuery(cq);

        List<Inventory> inventoryList = query.getResultList();

        return inventoryList;
    }

    public List<Inventory> getFeaturedTitle() {
        Query query = entityManager.createNamedQuery("Inventory.findFeaturedTitle");
        return query.getResultList();
    }

    /**
     * Get invoice by page
     *
     * @return
     * @throws SQLException
     */
    public List<Inventory> getPaginated() throws SQLException {
        int pageNumber = this.getPage();

        Query query = entityManager.createQuery("From Inventory i");
        query.setFirstResult((pageNumber - 1) * pageSize);
        query.setMaxResults(pageSize);

        Map<Integer, Boolean> map = this.getPagination();

        return query.getResultList();
    }

    /**
     * Get previously viewed inventory
     *
     * @return
     */
    public List<Inventory> getPreviouslyViewed() {
        List<Inventory> list = new ArrayList<>();
        Cookie cookie = cookieManager.getValueByName("previouslyViewed");

        if (cookie == null) {
            return list;
        }

        String[] isbnList = cookie.getValue().split(":");

        Query query = entityManager.createNamedQuery("Inventory.findByIsbnList");

        query.setParameter("isbnList", Arrays.asList(isbnList));

        return query.getResultList();
    }

    /**
     * Get the latest 4 books
     *
     * @return List<Inventory>
     */
    public List<Inventory> getJustArrived() {
        Query query = entityManager.createNamedQuery("Inventory.findJustArrived");
        query.setMaxResults(4);
        List<Inventory> result = query.getResultList();

        return result;
    }

    /**
     * Get book of the day
     *
     * @return Inventory
     */
    public Inventory getBookOfDay() {
        Query query = entityManager.createNamedQuery("Inventory.findByIsbn");
        query.setParameter("isbn", "978-0316184137");

        return (Inventory) query.getSingleResult();
    }

    /**
     * Get book by isbn
     *
     * @return
     */
    public Inventory getByIsbn() {
        Query queryGenre = entityManager.createNamedQuery("Inventory.findByIsbn");

        isbn = this.getParameterByName("isbn");
        this.setIsbn(isbn);

        queryGenre.setParameter("isbn", isbn);

        cookieManager.appendCookie("previouslyViewed", isbn);

        return (Inventory) queryGenre.getSingleResult();
    }

    /**
     * Get book by isbn
     *
     * @return
     */
    public Inventory getByIsbn(String isbn) {
        Query queryGenre = entityManager.createNamedQuery("Inventory.findByIsbn");
        queryGenre.setParameter("isbn", isbn);

        return (Inventory) queryGenre.getSingleResult();
    }

    /**
     * Get the latest 4 best sellers
     *
     * @return List<Inventory>
     */
    public List<Inventory> getBestSellers() {
        return entityManager.createNamedQuery("Inventory.findBestSellers").getResultList();
    }
//
    /**
     * Get books by genre
     *
     * @return List<Inventory>
     */
    public List<Inventory> getByCategory() {
        List<Inventory> result = null;

        try {
            Query query = entityManager.createNamedQuery("Inventory.findByGenre");
            query.setParameter("genreId", this.getGenre());

            result = query.getResultList();

            if (result.size() > 1) {

                Collections.sort(result, new Comparator<Inventory>() {
                    @Override
                    public int compare(Inventory inventory1, Inventory inventory2) {
                        if (inventory1.getLineItemCollection().size() > inventory2.getLineItemCollection().size()) {
                            return -1;
                        } else if (inventory1.getLineItemCollection().size() < inventory2.getLineItemCollection().size()) {
                            return 1;
                        } else {
                            return 0;
                        }
                    }
                });

            }
        } catch (NoResultException e) {

        }

        return result;
    }

    /**
     * Get inventory by invoice
     *
     * @return
     */
    public List<Inventory> getByInvoice() {
        Query query = entityManager.createNamedQuery("Inventory.findByInvoice");
        query.setParameter(1, this.getParameterByName("invoice"));
        query.setParameter(2, sessionManager.getUser().getId());

        return query.getResultList();
    }

    /**
     * Get list of pages
     *
     * @return
     */
    public Map<Integer, Boolean> getPagination() {
        Map<Integer, Boolean> list = new HashMap<>();

        Query query = entityManager.createNamedQuery("Inventory.count");

        long count = (long) (query.getResultList().get(0)) / pageSize + 1;
        int pageNumber = this.getPage();

        for (int i = 1; i < count; i++) {
            Boolean bool = (i == getPage());
            list.put(i, bool);
        }

        System.out.println(list);

        return list;
    }

    /**
     * Get invoice by id
     *
     * @return
     */
    private Invoice getInvoice() {
        Query query = entityManager.createNamedQuery("Invoice.findById");
        query.setParameter("id", this.getParameterByName("invoice"));

        return (Invoice) query.getSingleResult();
    }

    private Genre getGenre() throws NoResultException {
        Query queryGenre = entityManager.createNamedQuery("Genre.findByName");
        this.setCategory(this.getParameterByName("name"));
        queryGenre.setParameter("name", this.getCategory());

        return (Genre) queryGenre.getSingleResult();
    }

    /**
     * Get parameter by name
     *
     * @param parameterName
     * @return
     */
    private String getParameterByName(String parameterName) {
        return FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getRequestParameterMap()
                .get(parameterName);
    }

    /**
     * Get page parameter
     *
     * @return
     */
    private int getPage() {
        String pageParam = this.getParameterByName("page");

        if (pageParam == null) {
            return 1;
        }

        return Integer.parseInt(pageParam);
    }
}
