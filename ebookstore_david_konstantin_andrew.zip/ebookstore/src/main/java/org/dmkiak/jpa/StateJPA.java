package org.dmkiak.jpa;

import com.dmkiak.beans.State;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 * Bean to manage State Entity
 *
 * @author David Maignan <davidmaignan@gmail.com>
 *
 */
@Named
@RequestScoped
public class StateJPA implements Serializable {
    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;
    
    public List<State> getAll() throws SQLException {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<State> cq = cb.createQuery(State.class);
        Root<State> fish = cq.from(State.class);
        cq.select(fish);
        TypedQuery<State> query = entityManager.createQuery(cq);
        
        return query.getResultList();
    }
}