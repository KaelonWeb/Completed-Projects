package org.dmkiak.jpa;

import com.dmkiak.beans.Role;
import com.dmkiak.beans.User;
import com.dmkiak.controller.UserJpaController;
import com.dmkiak.session.SessionManager;
import com.dmkiak.translation.TranslationManager;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.UserTransaction;
import org.apache.log4j.Logger;

/**
 * User JPA
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@RequestScoped
@Named("userJPA")
public class UserJPA {
    private Logger logger = Logger.getLogger(UserJPA.class);
    
    @Inject
    SessionManager sessionManager;
    
    @Resource
    private UserTransaction userTransaction;

    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;
    
    @Inject
    UserJpaController ujc;
    
    @Inject
    TranslationManager translationManager;

    private FacesContext context;

    private String username;
    private String password;
    private String passwordRe;

    private int pageSize = 10;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPasswordRe() {
        return passwordRe;
    }

    public void setPasswordRe(String passwordRe) {
        this.passwordRe = passwordRe;
    }

    public String login() {
        String returnString = "error";
        Query query = entityManager.createNamedQuery("User.findByUsernamePassword");
        query.setParameter("username", this.getUsername());
        query.setParameter("password", this.getPassword());

        User user;

        try {
            user = (User)query.getSingleResult();
            returnString = "/profile/index?faces-redirect=true";

            initializeSession((User) user);
            
            if (user.getRoleId().getName().equals("manager")) {
                returnString = "/admin/index?faces-redirect=true";
            }
            

        } catch (NoResultException e) {
            this.setAttribute("error_login", e.getMessage());
            returnString = "registration";
        } catch (Exception e) {
            returnString = "error";
        }

        return returnString;
    }

    private void initializeSession(User user) {
        sessionManager.setUser(user);
    }

    private void destroySession() {
        FacesContext.getCurrentInstance().getExternalContext()
                .invalidateSession();
    }

    public String register() {
        try {
            String returnString = "success?faces-redirect=true";
            
            logger.error(this.getPassword());
            logger.error(this.getPasswordRe());
            
            String tset = translationManager.getMessage("registrationRePasswordError");
            logger.error(tset);

            if (!this.getPassword().equals(this.getPasswordRe())) {
                String message = translationManager.getMessage("registrationRePasswordError");
                throw new IllegalArgumentException(message);
            }
            
            if(this.getByUserName(this.getUsername()) != null) {
                String message = translationManager.getMessage("registrationUsernameErrorNotAvail");
                throw new IllegalArgumentException(String.format(message, this.getUsername()));
            }

            User user = new User();
            user.setUsername(this.getUsername());
            user.setPassword(this.getPassword());
            user.setRoleId(this.getClientRole());
            ujc.create(user);
            
            //Auto login
            sessionManager.setUser(user);

            return "/profile/index?faces-redirect=true";
        } catch(MySQLIntegrityConstraintViolationException ex){
            this.setAttribute("error_registration", ex.getMessage());
            logger.error(ex);
        }catch (IllegalArgumentException ex) {
            this.setAttribute("error_registration", ex.getMessage());
        }catch (Exception ex) {
            this.setAttribute("error_registration", "An error has occured during the registration.");
            logger.error(ex);
        }

        return "/registration";
    }

    private Role getClientRole() {
        Query query = entityManager.createNamedQuery("Role.findByName");
        query.setParameter("name", "consumer");

        return (Role) query.getSingleResult();
    }
    
    /**
     * Logout
     * @return string
     */
    public String logout() {
        destroySession();

        return "/index?faces-redirect=true";
    }
    
    /**
     * Get all user
     * @return
     * @throws SQLException 
     */
    public List<User> getAll() throws SQLException {

        int pageNumber = this.getPage();

        Query query = entityManager.createQuery("From User i");
        query.setFirstResult((pageNumber - 1) * pageSize);
        query.setMaxResults(pageSize);

        Map<Integer, Boolean> map = this.getPagination();

        logger.error(map);

        return query.getResultList();
    }
    
    /**
     * Get user by id
     * @return User
     */
    public User getById() {
        int id = Integer.valueOf(this.getParameterByName("id"));
        
        Query query = entityManager.createNamedQuery("User.findById");
        query.setParameter("id", id);
        
        return (User)query.getSingleResult();
    }
    
    private User getByUserName(String username){
        User result = null;
        
        try{
           result = (User)(entityManager.createNamedQuery("User.findByUsername")
                   .setParameter("username", username)
                   .getSingleResult());
        }catch(Exception e){
            
        }
        
        return result;
    }
    
    /**
     * Get list of pages
     * @return 
     */
    public Map<Integer, Boolean> getPagination() {
        Map<Integer, Boolean> list = new HashMap<>();

        Query query = entityManager.createNamedQuery("User.count");

        long count = (long) (query.getResultList().get(0)) / pageSize + 1;
        int pageNumber = this.getPage();

        for (int i = 1; i <= count; i++) {
            Boolean bool = (i == getPage());
            list.put(i, bool);
        }

        System.out.println(list);

        return list;
    }
    
    /**
     * Get page parameter
     * @return page
     */
    private int getPage() {
        String pageParam = this.getParameterByName("page");

        if (pageParam == null) {
            return 1;
        }

        logger.error(pageParam);

        return Integer.parseInt(pageParam);
    }
    
    /**
     * Set attribute in the request
     * @param attribute
     * @param value 
     */
    private void setAttribute(String attribute, String value) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        
        HttpServletRequest request = (HttpServletRequest)facesContext.getExternalContext().getRequest();
        
        request.setAttribute(attribute, value);
    }
    
    /**
     * Get request parameter
     * @param parameterName
     * @return 
     */
    private String getParameterByName(String parameterName) {
        FacesContext facesContext = FacesContext.getCurrentInstance();

        return facesContext.getExternalContext().getRequestParameterMap().get(parameterName);
    }
}
