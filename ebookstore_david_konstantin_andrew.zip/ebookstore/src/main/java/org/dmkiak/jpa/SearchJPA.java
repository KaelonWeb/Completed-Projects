package org.dmkiak.jpa;

import com.dmkiak.beans.Inventory;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;
import org.apache.log4j.Logger;

/**
 * Search JPA
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class SearchJPA implements Serializable {

    @Inject
    private InventoryJPA inventoryJPA;

    @Resource
    private UserTransaction userTransaction;

    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;

    private String searchField;
    
    private List<Inventory> result;

    private static final Logger logger = Logger.getLogger(InventoryJPA.class);

    public String getSearchField() {
        return searchField;
    }

    public void setSearchField(String searchField) {
        this.searchField = searchField;
    }

    public List<Inventory> getResult() {
        return result;
    }

    public void setResult(List<Inventory> result) {
        this.result = result;
    }
    
    /**
     * Search inventory by isbn, title, author
     * @return List of inventories
     */
    public List<Inventory> getSearch() {
        
        logger.error(this.getSearchField());

        //Check for ISBN
        List<Inventory> result = new ArrayList<>();
        
        if(searchField == null || searchField.equals("")) {
            return result;
        }
        
        searchField = this.getParameterByName("searchField");

        //Isbn
        if (searchField.matches("[0-9]{3}-[0-9]{10}")) {
            Inventory inventory = inventoryJPA.getByIsbn(searchField);

            if (inventory != null) {
                result.add(inventory);
            }
        } else {
            //Search by title
            Query query = entityManager.createNamedQuery("Inventory.findSearch");
            query.setParameter("searchValue", "%" + searchField + "%");

            List<Inventory> resultSearch = query.getResultList();

            result.addAll(resultSearch);
        }

        return result;
    }
    
    /**
     * Get parameter by name
     * @param parameterName
     * @return 
     */
    private String getParameterByName(String parameterName) {
        FacesContext facesContext = FacesContext.getCurrentInstance();

        return facesContext.getExternalContext().getRequestParameterMap().get(parameterName);
    }
}
