package org.dmkiak.jpa;

import com.dmkiak.beans.Inventory;
import com.dmkiak.beans.User;
import com.dmkiak.beans.Wishlist;
import com.dmkiak.cart.Cart;
import com.dmkiak.controller.UserJpaController;
import com.dmkiak.controller.WishlistJpaController;
import com.dmkiak.session.SessionManager;
import java.util.Collection;
import java.util.logging.Level;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;
import org.apache.log4j.Logger;

/**
 * WishList controller
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class WishListJPA {

    private Logger logger = Logger.getLogger(WishListJPA.class);

    @Resource
    private UserTransaction userTransaction;

    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;

    @Inject
    WishlistJpaController wjc;

    @Inject
    SessionManager sessionManager;

    @Inject
    UserJpaController ujc;

    /**
     * Get wishlist by user
     *
     * @return
     */
    public Collection<Wishlist> getAllByUser() {
        User user = ujc.findUser(sessionManager.getUser().getId());

        return user.getWishlistCollection();
    }

    /**
     * Add a new wishList
     *
     * @return
     */
    public String add() {
        try {
            String isbn = this.getParameterByName("isbn");

            Query bookQuery = entityManager.createNamedQuery("Inventory.findByIsbn");
            bookQuery.setParameter("isbn", isbn);

            Inventory book = (Inventory) bookQuery.getSingleResult();

            Wishlist wishlist = new Wishlist();
            wishlist.setIsbn(book);
            wishlist.setUserId(sessionManager.getUser());

            wjc.create(wishlist);
        } catch (NoResultException e) {
            logger.error("Wishlist not saved");
        } catch (Exception e) {
            logger.error("Wishlist not saved");
        }

        return "/bookDetail";
    }

    public String fromBasketToWishlist(Inventory inventory) {
        Wishlist wishlist = new Wishlist();
        wishlist.setIsbn(inventory);
        wishlist.setUserId(sessionManager.getUser());

        try {
            wjc.create(wishlist);
            
            //Delete from basket
            Cart cart = sessionManager.getCart();
            cart.remove(inventory);
            
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(WishListJPA.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return "/basket";
    }
    
    public String removeFromWishList(Wishlist wishlist) {
        try {
            wjc.destroy(wishlist.getId());            
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(WishListJPA.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return "/profile/wishlist";
    }

    /**
     * Check if inventory is in user wishList;
     *
     * @param inventory
     * @return
     */
    public boolean isWishListed(Inventory inventory) {
        User user = ujc.findUser(sessionManager.getUser().getId());

        for (Wishlist wishlist : user.getWishlistCollection()) {
            if (wishlist.getIsbn().equals(inventory)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Retrieve request parameters by name
     *
     * @param parameterName
     * @return
     */
    private String getParameterByName(String parameterName) {
        FacesContext facesContext = FacesContext.getCurrentInstance();

        return facesContext.getExternalContext().getRequestParameterMap().get(parameterName);
    }
}
