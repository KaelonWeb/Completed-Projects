package org.dmkiak.jpa;

import com.dmkiak.beans.Client;
import com.dmkiak.beans.Country;
import com.dmkiak.beans.State;
import com.dmkiak.beans.Title;
import com.dmkiak.beans.User;
import com.dmkiak.controller.ClientJpaController;
import com.dmkiak.controller.UserJpaController;
import com.dmkiak.session.SessionManager;
import java.util.Date;
import javax.annotation.Resource;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;
import javax.validation.ConstraintViolationException;
import org.apache.log4j.Logger;

/**
 * Client JPA
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@RequestScoped
@Named("clientJPA")
public class ClientJPA {
    private static final Logger logger = Logger.getLogger(ClientJPA.class);

    @Resource
    private UserTransaction userTransaction;
    
    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;
    
    @Inject
    SessionManager sessionManager;
    
    @Inject
    ClientJpaController cjc;
    
    @Inject
    UserJpaController ujc;
    
    private FacesContext context;

    private String title;
    private String fname;
    private String lname;
    private String companyName;
    private String email;
    private String phoneHome;
    private String phoneCell;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String country;
    private String postalCode;
    
    private boolean exist = false;

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getPhoneHome() {
        return phoneHome;
    }

    public void setPhoneHome(String phoneHome) {
        this.phoneHome = phoneHome;
    }

    public String getPhoneCell() {
        return phoneCell;
    }

    public void setPhoneCell(String phoneCell) {
        this.phoneCell = phoneCell;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public boolean isExist() {
        Query query = entityManager.createNamedQuery("Client.findByUserId");
        User user = sessionManager.getUser();
        
        try{
            Client client = (Client)query.setParameter("userId", user.getId()).getSingleResult();
            
            exist = true;           
            
        } catch(NoResultException e){
            exist = false;
        } catch(Exception e){
            logger.error("ClientJPA isExist has an issue. Please investigate", new Exception("ClientJPA isExist has an issue. Please investigate"));
        }
        
        return exist;
    }

    public Client getClient() {  
        Client client = null;
        try{
            entityManager.clear();
            Query query = entityManager.createNamedQuery("Client.findByUserId");
            User user = sessionManager.getUser();
            client = (Client)query.setParameter("userId", user.getId()).getSingleResult();
            
        } catch(NoResultException e){
            exist = false;
        } 
        
        return client;
    }

    public void setExist(boolean exist) {
        this.exist = exist;
    }
    
    public Boolean exist() {
        
        return true;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    } 
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public FacesContext getContext() {
        return context;
    }

    public void setContext(FacesContext context) {
        this.context = context;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    
    public String edit(Client client) {
        this.setTitle(client.getTitleId().getName());
        this.setFname(client.getFirstName());
        this.setLname(client.getLastName());
        this.setEmail(client.getEmail());
        this.setCompanyName(client.getCompanyName());
        this.setAddress1(client.getAddress1());
        this.setAddress2(client.getAddress2());
        this.setPhoneHome(client.getPhoneHome());
        this.setPhoneCell(client.getPhoneCell());
        this.setCity(client.getCity());
        this.setPostalCode(client.getPostalCode());
        this.setState(client.getStateId().getName());
        this.setCountry(client.getCountryId().getName());
        
        return "editProfile";
    }

    public String save() {
        String returnString = "/profile/index?faces-redirect=true";
        
        Client client = this.generateClientEntity();
                
        try {
            cjc.create(client);            
        }catch (ConstraintViolationException e){
            logger.error(e);
        } catch (Exception ex) {
            logger.error(ex);
            logger.error(client);
            returnString = "checkout";
        }

        return returnString;
    }
    
    public String update() {
        String returnString = "/profile/index?faces-redirect=true";

        Client client = this.generateClientEntity();
        
        try {
            cjc.edit(client);
        }catch (ConstraintViolationException e){
            e.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.error(client);
            returnString = "editProfile";
        }

        return returnString;
    }
    
    private Client generateClientEntity(){
        int userId = sessionManager.getUser().getId();
        
        Client client = new Client();
        client.setTitleId(this.getTitleEntity(this.getTitle()));
        client.setFirstName(this.getFname());
        client.setLastName(this.getLname());
        client.setCompanyName(this.getCompanyName());
        client.setEmail(this.getEmail());
        client.setAddress1(this.getAddress1());
        client.setAddress2(this.getAddress2());
        client.setCity(this.getCity());
        client.setPostalCode(this.getPostalCode());
        client.setPhoneHome(this.getPhoneHome());
        client.setPhoneCell(this.getPhoneCell());
        client.setUser(this.getUserEntity(userId));
        client.setUserId(userId);
        client.setStateId(this.getStateEntity(this.getState()));
        client.setCountryId(this.getCountryEntity(this.getCountry()));
        client.setCreatedAt(new Date());
        
        return client;
    }
    
    private User getUserEntity(int userId) throws NoResultException {
        Query query = entityManager.createNamedQuery("User.findById");
        query.setParameter("id", userId);
        
        return (User)query.getSingleResult();
    }
    
    private Title getTitleEntity(String name) throws NoResultException {
        Query query = entityManager.createNamedQuery("Title.findByName");
        query.setParameter("name", this.getTitle());
        
        return (Title)query.getSingleResult();
    }
    
    private State getStateEntity(String name) throws NoResultException {
        Query query = entityManager.createNamedQuery("State.findByName");
        query.setParameter("name", this.getState());
        
        return (State)query.getSingleResult();
    }
    
    private Country getCountryEntity(String name) throws NoResultException{
        Query query = entityManager.createNamedQuery("Country.findByName");
        query.setParameter("name", this.getCountry());
        
        return (Country)query.getSingleResult();
    }
}
