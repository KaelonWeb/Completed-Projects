package org.dmkiak.jpa;

import com.dmkiak.beans.Genre;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import javax.annotation.Resource;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;

/**
 * Genre JPA
 *
 * @author David Maignan <davidmaignan@gmail.com>
 *
 */
@Named
@RequestScoped
public class GenreJPA implements Serializable {

    @Resource
    private UserTransaction userTransaction;

    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;
    
    public List<Genre> getAllOrderedByName() throws SQLException {
        Query query = entityManager.createNamedQuery("Genre.findAllOrderBy");
        
        List<Genre> result = query.getResultList();
        
        return result;   
    }
    
    
}