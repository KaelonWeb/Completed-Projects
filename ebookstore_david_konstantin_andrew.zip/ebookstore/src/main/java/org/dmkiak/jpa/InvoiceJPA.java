package org.dmkiak.jpa;

import com.dmkiak.beans.Invoice;
import com.dmkiak.session.SessionManager;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.apache.log4j.Logger;

/**
 * Bean to manage Invoice Entity
 *
 * @author David Maignan <davidmaignan@gmail.com>
 *
 */
@Named
@RequestScoped
public class InvoiceJPA implements Serializable {

    private static final Logger logger = Logger.getLogger(InvoiceJPA.class);

    private int pageSize = 10;

    @Inject
    SessionManager sessionManager;

    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;

    public List<Invoice> getAllByUser() throws SQLException {
        Query query = entityManager.createNamedQuery("Invoice.findByUserId");
        query.setParameter("userId", sessionManager.getUser());

        return query.getResultList();
    }

    public Invoice getLast() {
        Query query = entityManager.createNamedQuery("Invoice.findLastByUser");
        query.setParameter("userId", sessionManager.getUser());
        query.setMaxResults(1);

        return (Invoice) query.getSingleResult();
    }

    public List<Invoice> getAll() throws SQLException {

        int pageNumber = this.getPage();

        Query query = entityManager.createQuery("From Invoice i");
        query.setFirstResult((pageNumber - 1) * pageSize);
        query.setMaxResults(pageSize);

        Map<Integer, Boolean> map = this.getPagination();

        logger.error(map);

        return query.getResultList();
    }

    public Map<Integer, Boolean> getPagination() {
        Map<Integer, Boolean> list = new HashMap<>();

        Query query = entityManager.createNamedQuery("Invoice.count");

        long count = (long) (query.getResultList().get(0)) / pageSize + 1;
        int pageNumber = this.getPage();

        for (int i = 1; i < count; i++) {
            Boolean bool = (i == getPage());
            list.put(i, bool);
        }

        System.out.println(list);

        return list;
    }

    public Invoice getById() {
        int id = Integer.valueOf(this.getParameterByName("id"));

        Query query = entityManager.createNamedQuery("Invoice.findById");
        query.setParameter("id", id);

        return (Invoice) query.getSingleResult();
    }

    public Invoice getByUserAndId() {
        int id = Integer.valueOf(this.getParameterByName("invoice"));

        Query query = entityManager.createNamedQuery("Invoice.findByUserAndId");
        query.setParameter("id", id);
        query.setParameter("userId", sessionManager.getUser());

        return (Invoice) query.getSingleResult();
    }

    private int getPage() {
        String pageParam = this.getParameterByName("page");

        if (pageParam == null) {
            return 1;
        }

        logger.error(pageParam);

        return Integer.parseInt(pageParam);
    }

    private String getParameterByName(String parameterName) {
        FacesContext facesContext = FacesContext.getCurrentInstance();

        return facesContext.getExternalContext().getRequestParameterMap().get(parameterName);
    }
}
