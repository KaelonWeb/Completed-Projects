package org.dmkiak.jpa;

import com.dmkiak.beans.Inventory;
import com.dmkiak.beans.Review;
import com.dmkiak.beans.User;
import com.dmkiak.session.SessionManager;
import com.dmkiak.translation.TranslationManager;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;
import javax.inject.Inject;
import javax.inject.Named;
import org.apache.log4j.Logger;

/**
 *
 * @author david
 */
@Named
@RequestScoped
public class ReviewJPA {
    
    private Logger logger = Logger.getLogger(InventoryJPA.class);
    
    @Inject
    SessionManager sessionManager;
    
    @Inject
    TranslationManager translationManager;
    
    /**
     * Get rating values
     * @return 
     */
    public List<Integer> getRatingList() {
        ArrayList<Integer> list = new ArrayList<>();

        for (int i = 1; i <= 5; i += 1) {
            list.add(i);
        }

        return list;
    }
    
    /**
     * Validate lenght of a review
     * @param f
     * @param c
     * @param obj 
     */
    public void validateReview(FacesContext f, UIComponent c, Object obj){
        String s = (String)obj;
        
        if(s.length() < 20) {
            String message = translationManager.getMessage("reviewErrorValidator");
            throw new ValidatorException(new FacesMessage(message));
        }
    }
    
    /**
     * Check if a user can write only one review per book
     * @param inventory
     * @return 
     */
    public boolean isReviewed(Inventory inventory){
        User user = sessionManager.getUser();
        logger.error(user);
        for (Review review : inventory.getReviewCollection()) {
            logger.error(review.getUserId());
            if (review.getUserId().equals(user)) {
                return true;
            }
        }
        
        return false;
    }
}
