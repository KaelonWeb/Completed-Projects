package com.dmkiak.managed.bean;

import com.dmkiak.beans.Inventory;
import com.dmkiak.beans.Wishlist;
import com.dmkiak.cart.Cart;
import com.dmkiak.controller.WishlistJpaController;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import com.dmkiak.session.SessionManager;
import java.io.IOException;
import java.util.logging.Level;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;
import org.apache.log4j.Logger;

@RequestScoped
@Named
public class CartBean {
    private Logger logger = Logger.getLogger(CartBean.class);

    @Resource
    private UserTransaction userTransaction;

    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;

    private String outcome = "bookDetail";
    private Cart cart;

    private String isbn;

    @Inject
    SessionManager sessionManager;
    
    @Inject 
    WishlistJpaController wjc;

    public String add() {

        try {
            String isbn = this.getParameterByName("isbn");

            Query bookQuery = entityManager.createNamedQuery("Inventory.findByIsbn");
            bookQuery.setParameter("isbn", isbn);

            Inventory book = (Inventory) bookQuery.getSingleResult();

            cart = sessionManager.getCart();
            cart.addInventory(book);

            sessionManager.setCart(cart);
        } catch (NoResultException e) {
            //logger.error("No book found");
        } catch (Exception e) {
            //logger.error("Cannot add from cart");
        }

        return "bookDetail";
    }

    public String addFromWishList(Wishlist wishlist) throws IOException {
        cart = sessionManager.getCart();
        cart.addInventory(wishlist.getIsbn());

        sessionManager.setCart(cart);
        
        //Delete wishlist
        try{
            wjc.destroy(wishlist.getId());
            logger.error("wishlist deleted");
        } catch (RollbackFailureException ex) {
            java.util.logging.Logger.getLogger(CartBean.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(CartBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return "/profile/wishlist";
    }

    public String remove() {
        try {
            String isbn = this.getParameterByName("isbn");

            Query bookQuery = entityManager.createNamedQuery("Inventory.findByIsbn");
            bookQuery.setParameter("isbn", isbn);

            Inventory book = (Inventory) bookQuery.getSingleResult();

            cart = sessionManager.getCart();
            cart.remove(book);
            sessionManager.setCart(cart);
        } catch (NoResultException e) {
            //logger.error("No book found");
        } catch (Exception e) {
            //logger.error("Cannot remove from cart");
        }

        return "basket";
    }

    public void setOutcome(String outcome) {
        this.outcome = outcome;
    }

    private String getParameterByName(String parameterName) {
        FacesContext facesContext = FacesContext.getCurrentInstance();

        return facesContext.getExternalContext().getRequestParameterMap().get(parameterName);
    }
}
