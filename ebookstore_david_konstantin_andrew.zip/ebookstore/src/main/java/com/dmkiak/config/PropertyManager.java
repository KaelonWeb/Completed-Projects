package com.dmkiak.config;

import java.io.IOException;
import java.util.Properties;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Named;

/**
 *
 * @author david
 */
@Named
@RequestScoped
public class PropertyManager {
    
    /**
     * Get 
     * @param property
     * @return
     * @throws IOException 
     */
    public String getProperty(String property) throws IOException{
        Properties properties = new Properties();
        
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        properties.load(externalContext.getResourceAsStream("/WEB-INF/ebookstore.properties"));
        
        return properties.getProperty(property);
    }
}
