package com.dmkiak.translation;

import java.util.MissingResourceException;
import java.util.ResourceBundle;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

/**
 *
 * @author david
 */
@Named
@RequestScoped
public class TranslationManager {
    
    /**
     * 
     * @return 
     */
    private ResourceBundle getResourceBundle(){
        return ResourceBundle.getBundle("/com/dmkiak/bundles/messages", FacesContext.getCurrentInstance().getViewRoot().getLocale());
    }
    
    /**
     * Get translation by key
     * @param key
     * @return 
     */
    public String getMessage(String key) {
        try{
            return this.getResourceBundle().getString(key);
        }catch (MissingResourceException e){
            return key;
        }
    }
}
