package com.dmkiak.admin;

import com.dmkiak.beans.Invoice;
import com.dmkiak.report.TopSeller;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;
import org.apache.log4j.Logger;

/**
 * SaleAdmin JPA Bean
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class SaleAdminJPA {

    private Logger logger = Logger.getLogger(SaleAdminJPA.class);

    @Resource
    private UserTransaction userTransaction;

    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;

    private List<TopSeller> topSellerList;
    private List<Invoice> topClientByInvoice;

    private String fromDate;
    private String toDate;

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public List<TopSeller> getTopSellerList() {
        return topSellerList;
    }

    public List<Invoice> getTopClientByInvoice() {
        return topClientByInvoice;
    }
    
    /**
     * Retrieve top sellers
     */
    public void topSellers() {
        Query query = entityManager.createNamedQuery("Invoice.findTopSellers");
        query.setParameter(1, this.getFromDate() + " 00:00:00");
        query.setParameter(2, this.getToDate() + " 23:59:59");

        topSellerList = query.getResultList();

        logger.error(topSellerList.size());
    }
    
    /**
     * Retrieve top clients 
     */
    public void topClients() {
        Query query = entityManager.createNamedQuery("Invoice.findTopClients");
        query.setParameter(1, this.getFromDate() + " 00:00:00");
        query.setParameter(2, this.getToDate() + " 23:59:59");

        topClientByInvoice = query.getResultList();
    }
}
