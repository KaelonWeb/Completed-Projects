/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dmkiak.admin;

import com.dmkiak.beans.Invoice;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;
import org.apache.log4j.Logger;

/**
 *
 * @author david
 */
@Named
@RequestScoped
public class InvoiceAdminJPA {
    private Logger logger = Logger.getLogger(InventoryAdminJPA.class);
    
    @PersistenceContext(name = "ebookstorePU")
    EntityManager entityManager;
    
    @Resource
    UserTransaction userTransaction;
    
    public List<Invoice> getNewList(){
        return entityManager
                .createNamedQuery("Invoice.findNew")
                .setParameter("createdAt", this.getToday())
                .getResultList();
    }
    
    private Date getToday(){
        Calendar calendar = GregorianCalendar.getInstance();
        
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        
        logger.error(calendar.getTime());
        
        return calendar.getTime();
    }
}
