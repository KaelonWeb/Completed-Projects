package com.dmkiak.admin;

import com.dmkiak.beans.Invoice;
import com.dmkiak.beans.Review;
import com.dmkiak.controller.ReviewJpaController;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;
import org.apache.log4j.Logger;

/**
 * Controller to manage review for administrator
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class ReviewAdminJPA {

    private Logger logger = Logger.getLogger(ReviewAdminJPA.class);

    private final int pageSize = 10;

    @PersistenceContext(name = "ebookstorePU")
    EntityManager entityManager;

    @Resource
    UserTransaction userTransaction;

    @Inject
    ReviewJpaController rjc;

    private List<Review> reviewList;

    public List<Review> getUnapprovedReviewList() {
        reviewList = entityManager
                .createNamedQuery("Review.findByApprovalStatus")
                .setParameter("approvalStatus", false)
                .getResultList();
        return reviewList;
    }

    public void approve(Review review) {
        review.setApprovalStatus(true);
        review.setApprovedAt(new Date());

        try {
            rjc.edit(review);
        } catch (RollbackFailureException ex) {
            //Logger.getLogger(ReviewAdminJPA.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            //Logger.getLogger(ReviewAdminJPA.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public List<Invoice> getPaginated() throws SQLException {

        int pageNumber = this.getPage();

        Query query = entityManager.createQuery("From Review i");
        query.setFirstResult((pageNumber - 1) * pageSize);
        query.setMaxResults(pageSize);

        Map<Integer, Boolean> map = this.getPagination();
        
        logger.error("Map" + map);

        return query.getResultList();
    }
    
    public Map<Integer, Boolean> getPagination() {
        Map<Integer, Boolean> list = new HashMap<>();

        Query query = entityManager.createNamedQuery("Review.count");
        
        logger.error("Total: " + query.getResultList().get(0));

        long count = (long) (query.getResultList().get(0)) / pageSize + 1;
        
        int pageNumber = this.getPage();

        for (int i = 1; i <= Math.ceil(count); i++) {
            Boolean bool = (i == getPage());
            list.put(i, bool);
        }

        return list;
    }

    private int getPage() {
        String pageParam = this.getParameterByName("page");

        if (pageParam == null) {
            return 1;
        }

        return Integer.parseInt(pageParam);
    }

    private String getParameterByName(String parameterName) {
        FacesContext facesContext = FacesContext.getCurrentInstance();

        return facesContext.getExternalContext().getRequestParameterMap().get(parameterName);
    }
}
