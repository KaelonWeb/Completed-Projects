package com.dmkiak.admin;

import com.dmkiak.beans.User;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

/**
 * Controller to manage user for admin site
 * 
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class UserAdminJPA {
    
    @PersistenceContext(name = "ebookstorePU")
    EntityManager entityManager;
    
    @Resource
    UserTransaction userTransaction;
    
    public List<User> getNewUserList(){
        
        new Date().getTime();
        
        return entityManager
                .createNamedQuery("User.findNewUser")
                .setParameter("createdAt", new Timestamp(this.getToday().getTime()))
                .getResultList();
    }
    
    private Date getToday() {
        Calendar calendar = GregorianCalendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        
        return calendar.getTime();
    }
}
