package com.dmkiak.admin;

import com.dmkiak.beans.Genre;
import com.dmkiak.beans.Inventory;
import com.dmkiak.beans.Invoice;
import com.dmkiak.controller.InventoryJpaController;
import com.dmkiak.controller.exceptions.NonexistentEntityException;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import com.dmkiak.converter.StringByteConverter;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import org.apache.log4j.Logger;
import org.dmkiak.jpa.InventoryJPA;

/**
 * Inventory JPA Bean
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class InventoryAdminJPA implements Serializable {

    private static final Logger logger = Logger.getLogger(InventoryAdminJPA.class);
    private final int pageSize = 10;
    private String isbn;
    private String title;
    private String author;
    private String publisher;
    private int numberOfPages;
    private String description;
    private Genre genre;
    private BigDecimal wholesalePrice;
    private BigDecimal listPrice;
    private boolean removalStatus;

    @Inject
    private StringByteConverter stringConverter;

    @Inject
    private InventoryJpaController ijc;

    @Resource
    private UserTransaction userTransaction;

    @PersistenceContext(unitName = "ebookstorePU")
    private EntityManager entityManager;

    public String edit() throws IOException {
        String isbn = this.getParameterByName("isbn");
        
        Query query = entityManager.createNamedQuery("Inventory.findByIsbnAdmin");
        query.setParameter("isbn", this.getParameterByName("isbn"));
        
        Inventory inventory = (Inventory)query.getSingleResult();

        this.setIsbn(inventory.getIsbn());
        this.setTitle(inventory.getTitle());
        this.setAuthor(inventory.getAuthor());
        this.setPublisher(inventory.getPublisher());
        this.setNumberOfPages(inventory.getNumberOfPages());
        this.setDescription(stringConverter.converteByteToString(inventory.getDescription()));
        this.setWholesalePrice(inventory.getWholesalePrice());
        this.setListPrice(inventory.getListPrice());
        this.setRemovalStatus(inventory.getRemovalStatus());

        return "/admin/inventory/edit";
    }

    public String update() {

        Query query = entityManager.createNamedQuery("Inventory.findByIsbnAdmin");
        query.setParameter("isbn", this.getIsbn());

        Inventory inventory = (Inventory) query.getSingleResult();

        try {
            inventory.setIsbn(this.getIsbn());
            inventory.setTitle(this.getTitle());
            inventory.setAuthor(this.getAuthor());
            inventory.setPublisher(this.getPublisher());
            inventory.setNumberOfPages(this.getNumberOfPages());
            inventory.setDescription(this.getDescription().getBytes(Charset.forName("UTF-8")));
            inventory.setWholesalePrice(this.getWholesalePrice());
            inventory.setListPrice(this.getListPrice());
            
            logger.error(this.isRemovalStatus());
            
            inventory.setRemovalStatus(this.isRemovalStatus());
            ijc.edit(inventory);

            return "/admin/inventory/index?faces-redirect=true";
        } catch (NonexistentEntityException ex) {
            java.util.logging.Logger.getLogger(InventoryAdminJPA.class.getName()).log(Level.SEVERE, null, ex);
        } catch (RollbackFailureException ex) {
            java.util.logging.Logger.getLogger(InventoryAdminJPA.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(InventoryAdminJPA.class.getName()).log(Level.SEVERE, null, ex);
        }

        return "/admin/inventory/edit";
    }

    public List<Inventory> getAll() throws SQLException {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Inventory> cq = cb.createQuery(Inventory.class);
        Root<Inventory> fish = cq.from(Inventory.class);
        cq.select(fish);
        TypedQuery<Inventory> query = entityManager.createQuery(cq);

        List<Inventory> inventoryList = query.getResultList();

        return inventoryList;
    }

    public List<Invoice> getPaginated() throws SQLException {

        int pageNumber = this.getPage();

        Query query = entityManager.createQuery("From Inventory i");
        query.setFirstResult((pageNumber - 1) * pageSize);
        query.setMaxResults(pageSize);

        Map<Integer, Boolean> map = this.getPagination();

        logger.error(map);

        return query.getResultList();
    }

    private String getParameterByName(String parameterName) {
        FacesContext facesContext = FacesContext.getCurrentInstance();

        return facesContext.getExternalContext().getRequestParameterMap().get(parameterName);
    }

    public Map<Integer, Boolean> getPagination() {
        Map<Integer, Boolean> list = new HashMap<>();

        Query query = entityManager.createNamedQuery("Inventory.count");

        long count = (long) (query.getResultList().get(0)) / pageSize + 1;
        int pageNumber = this.getPage();

        for (int i = 1; i <= Math.ceil(count); i++) {
            Boolean bool = (i == getPage());
            list.put(i, bool);
        }
        
        return list;
    }

    private int getPage() {
        String pageParam = this.getParameterByName("page");

        if (pageParam == null) {
            return 1;
        }

        logger.error(pageParam);

        return Integer.parseInt(pageParam);
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public int getNumberOfPages() {
        return numberOfPages;
    }

    public void setNumberOfPages(int numberOfPages) {
        this.numberOfPages = numberOfPages;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Genre getGenre() {
        return genre;
    }

    public void setGenre(Genre genre) {
        this.genre = genre;
    }

    public BigDecimal getWholesalePrice() {
        return wholesalePrice;
    }

    public void setWholesalePrice(BigDecimal wholesalePrice) {
        this.wholesalePrice = wholesalePrice;
    }

    public BigDecimal getListPrice() {
        return listPrice;
    }

    public void setListPrice(BigDecimal listPrice) {
        this.listPrice = listPrice;
    }

    public boolean isRemovalStatus() {
        return removalStatus;
    }

    public void setRemovalStatus(boolean removalStatus) {
        this.removalStatus = removalStatus;
    }

}
