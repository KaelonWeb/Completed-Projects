package com.dmkiak.converter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

/**
 *
 * @author david
 */
@FacesConverter("descriptionConverter")
public class ByteConverter implements Converter {

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        throw new ConverterException("You must provide a string");
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value)  {
        try {
            return new String(serialize(value)).substring(27);
        } catch (IOException ex) {
            Logger.getLogger(ByteConverter.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return "Cannot show the description";
    }
    
    private byte[] serialize(Object obj) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ObjectOutputStream os = new ObjectOutputStream(out);
        os.writeObject(obj);
        return out.toByteArray();
    }
}
