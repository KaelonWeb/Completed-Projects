/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dmkiak.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

/**
 *
 * @author david
 */
@FacesConverter("stringTruncater")
public class StringTruncater implements Converter{

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        throw new ConverterException("You must provide a string");
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (!(value instanceof String)) {
            throw new ConverterException("You must provide a string");
        }
        
        if(((String)value).length() >= 40){
            value = ((String)value).substring(0, 40) + " ...";
        }
        
        return (String)value;
    }
}
