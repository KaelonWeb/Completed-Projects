/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dmkiak.converter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import javax.inject.Named;

/**
 *
 * @author david
 */
@Named
public class StringByteConverter {
    
    public String converteByteToString(byte[] value) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ObjectOutputStream os = new ObjectOutputStream(out);
        os.writeObject(value);
        
        return new String(out.toByteArray()).substring(27);
    }
}
