/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dmkiak.navigation;

/**
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
public class Crumb {
    private String value;
    private String outcome;
    private String parameterName;
    private String name;

    public Crumb() {
        value = null;
        outcome = null;
        parameterName = null;
        name = null;
    }
    
    public Crumb(String value){
        this.value = value;
    }

    public Crumb(String value, String outcome) {
        this.value = value;
        this.outcome = outcome;
    }

    public Crumb(String value, String outcome, String parameterName, String name) {
        super();
        this.value = value;
        this.outcome = outcome;
        this.parameterName = parameterName;
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getOutcome() {
        return outcome;
    }

    public void setOutcome(String outcome) {
        this.outcome = outcome;
    }

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
