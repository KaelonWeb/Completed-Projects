package com.dmkiak.navigation;

import com.dmkiak.navigation.Crumb;
import com.dmkiak.translation.TranslationManager;
import java.util.Enumeration;
import java.util.LinkedList;
import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;
import javax.inject.Named;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;
import org.dmkiak.jpa.InventoryJPA;

/**
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@RequestScoped
@Named
public class BreadCrumb {
    
    private static final Logger logger = Logger.getLogger(InventoryJPA.class);
    
    private FacesContext facesContext;
    
    private String servletPath;
    
    private LinkedList<Crumb> crumbList;
    
    @Inject
    TranslationManager translationManager;

    public LinkedList<Crumb> getCrumbList() {
        
        crumbList = new LinkedList<>();
        
        crumbList.add(new Crumb(translationManager.getMessage("Home"), "index"));
        
        facesContext = FacesContext.getCurrentInstance();
        
        HttpServletRequest origRequest = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
        
        Enumeration<String> parameterList = origRequest.getParameterNames();
        
        while(parameterList.hasMoreElements()){
            String parameterName = parameterList.nextElement();
            Crumb crumb = new Crumb(origRequest.getParameter(parameterName), "category", "name", origRequest.getParameter(parameterName));
            crumbList.add(crumb);
            logger.error(crumb.getName());
        }
        
        if(origRequest.getRequestURI().matches("category")){
            
        }
        
        return crumbList;
    }
    
    
}
