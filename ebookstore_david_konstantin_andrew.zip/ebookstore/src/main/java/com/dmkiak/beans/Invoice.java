package com.dmkiak.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

//SELECT *, count(*) as total FROM invoice 
//LEFT JOIN lineItem 
//on invoice.id = lineItem.invoiceId
//WHERE createdAt > "2015-02-15" AND createdAt < "2015-04-31"
//GROUP BY lineItem.ISBN
//ORDER BY total DESC;

//Select *, SUM(invoice.totalNet) as totalNet, count(invoice.id) as total from invoice
//INNER JOIN user
//on invoice.userId = user.id
//GROUP BY invoice.userId
//ORDER BY total DESC;
/**
 * Invoice Entity
 *
 * @author Andrew
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Entity
@Table(name = "invoice", catalog = "eBookStore", schema = "")
@XmlRootElement
@SqlResultSetMappings({
    @SqlResultSetMapping(name = "findTopSellersMapping",
        classes = {
            @ConstructorResult(
                    targetClass = com.dmkiak.report.TopSeller.class,
                    columns = {
                        @ColumnResult(name = "invoiceId"),
                        @ColumnResult(name = "total"),
                        @ColumnResult(name = "isbn"),
                        @ColumnResult(name = "title"),
                        @ColumnResult(name = "createdAt")
                    }
            )
        }
    ),
    @SqlResultSetMapping(
        name = "findTopClientMapping",
        classes = {
            @ConstructorResult(
                    targetClass = com.dmkiak.report.TopClient.class,
                    columns = {
                        @ColumnResult(name = "username"),
                        @ColumnResult(name = "totalNet"),
                        @ColumnResult(name = "totalOrder")
                    }
            )
        }
    ),
    @SqlResultSetMapping(
        name = "findSalesByGenreMapping",
        classes = {
            @ConstructorResult(
                    targetClass = com.dmkiak.report.SaleReport.class,
                    columns = {
                        @ColumnResult(name = "genre"),
                        @ColumnResult(name = "amount"),
                        @ColumnResult(name = "week")
                    }
            )
        }
    )
})
@NamedNativeQueries({
    @NamedNativeQuery(name = "Invoice.findSalesByGenre",
            query = "SELECT g.name as genre, SUM(li.price) as amount, DATE_FORMAT(i.createdAt,'%v') as week "
            + "FROM invoice AS i "
            + "LEFT JOIN lineItem li ON i.id = li.invoiceId "
            + "LEFT JOIN inventory iv on li.ISBN = iv.ISBN "
            + "LEFT JOIN genre g on iv.genreId = g.id "
            + "GROUP BY g.id, week "
            + "ORDER BY week ASC",
            resultSetMapping = "findSalesByGenreMapping"),
    @NamedNativeQuery(name = "Invoice.findTopSellers",
            query = "SELECT i.id as invoiceId, "
            + "COUNT(li.ISBN) AS total, i.createdAt as createdAt, li.ISBN as isbn, iv.title as title "
            + "FROM invoice AS i "
            + "LEFT JOIN lineItem li ON i.id = li.invoiceId "
            + "LEFT JOIN inventory iv on li.ISBN = iv.ISBN "
            + "WHERE i.createdAt > ?1 AND i.createdAt < ?2 "
            + "GROUP BY li.ISBN ORDER BY total DESC",
            resultSetMapping = "findTopSellersMapping"),
    @NamedNativeQuery(name = "Invoice.findTopClients",
            query = "SELECT u.username as username, SUM(i.totalNet) as totalNet, "
                    + "count(i.id) as totalOrder "
                    + "FROM invoice as i "
                    + "LEFT JOIN user u on i.userId = u.id "
                    + "WHERE i.createdAt > ?1 AND i.createdAt < ?2 "
                    + "GROUP BY i.userId "
                    + "ORDER BY totalNet DESC", 
            resultSetMapping = "findTopClientMapping")
})
//Select *, SUM(invoice.totalNet) as totalNet, count(invoice.id) as total from invoice
//INNER JOIN user
//on invoice.userId = user.id
//GROUP BY invoice.userId
//ORDER BY total DESC;
@NamedQueries({
    @NamedQuery(name = "Invoice.findAll", query = "SELECT i FROM Invoice i"),
    @NamedQuery(name = "Invoice.findByUserId", query = "SELECT i FROM Invoice i WHERE i.userId = :userId"),
    @NamedQuery(name = "Invoice.findByUserAndId", query = "SELECT i FROM Invoice i WHERE i.id = :id AND i.userId = :userId"),
    @NamedQuery(name = "Invoice.findById", query = "SELECT i FROM Invoice i WHERE i.id = :id"),
    @NamedQuery(name = "Invoice.findByTotalNet", query = "SELECT i FROM Invoice i WHERE i.totalNet = :totalNet"),
    @NamedQuery(name = "Invoice.findByGst", query = "SELECT i FROM Invoice i WHERE i.gst = :gst"),
    @NamedQuery(name = "Invoice.findByPst", query = "SELECT i FROM Invoice i WHERE i.pst = :pst"),
    @NamedQuery(name = "Invoice.findByTotalGross", query = "SELECT i FROM Invoice i WHERE i.totalGross = :totalGross"),
    @NamedQuery(name = "Invoice.count", query = "Select Count(e) from Invoice e"),
    @NamedQuery(name = "Invoice.findNew", query = "SELECT i FROM Invoice i WHERE i.createdAt > :createdAt"),
    @NamedQuery(name = "Invoice.findLastByUser", query = "SELECT i FROM Invoice i WHERE i.userId = :userId ORDER BY i.id DESC"),
    @NamedQuery(name = "Invoice.findByCreatedAt", query = "SELECT i FROM Invoice i WHERE i.createdAt = :createdAt")})
public class Invoice implements Serializable {

    @OneToMany(mappedBy = "invoiceId")
    private Collection<LineItem> lineItemCollection;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "totalNet", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalNet;

    @Basic(optional = false)
    @NotNull
    @Column(name = "gst", nullable = false, precision = 10, scale = 2)
    private BigDecimal gst;

    @Basic(optional = false)
    @NotNull
    @Column(name = "pst", nullable = false, precision = 10, scale = 2)
    private BigDecimal pst;

    @Basic(optional = false)
    @NotNull
    @Column(name = "totalGross", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalGross;

    @Basic(optional = false)
    @NotNull
    @Column(name = "createdAt", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @JoinColumn(name = "userId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private User userId;

    public Invoice() {
        this.createdAt = new Date();
    }

    public Invoice(Integer id) {
        this.id = id;
    }

    public Invoice(Integer id, BigDecimal totalNet, BigDecimal gst, BigDecimal pst, BigDecimal totalGross, Date createdAt) {
        this.id = id;
        this.totalNet = totalNet;
        this.gst = gst;
        this.pst = pst;
        this.totalGross = totalGross;
        this.createdAt = createdAt;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BigDecimal getTotalNet() {
        return totalNet;
    }

    public void setTotalNet(BigDecimal totalNet) {
        this.totalNet = totalNet;
    }

    public BigDecimal getGst() {
        return gst;
    }

    public void setGst(BigDecimal gst) {
        this.gst = gst;
    }

    public BigDecimal getPst() {
        return pst;
    }

    public void setPst(BigDecimal pst) {
        this.pst = pst;
    }

    public BigDecimal getTotalGross() {
        return totalGross;
    }

    public void setTotalGross(BigDecimal totalGross) {
        this.totalGross = totalGross;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public User getUserId() {
        return userId;
    }

    public void setUserId(User userId) {
        this.userId = userId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Invoice)) {
            return false;
        }
        Invoice other = (Invoice) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.dmkiak.beans.Invoice[ id=" + id + " ]";
    }

    @XmlTransient
    public Collection<LineItem> getLineItemCollection() {
        return lineItemCollection;
    }

    public void setLineItemCollection(Collection<LineItem> lineItemCollection) {
        this.lineItemCollection = lineItemCollection;
    }
}
