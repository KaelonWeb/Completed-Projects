/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dmkiak.beans;

import java.io.Serializable;
import java.lang.annotation.Native;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.NamedNativeQueries;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * Inventory entity
 *
 * @author Andrew
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Entity
@Table(name = "inventory", catalog = "eBookStore", schema = "")
@SqlResultSetMappings({
    @SqlResultSetMapping(name = "best-sellers", entities = {
        @EntityResult(entityClass = Inventory.class)}),
    @SqlResultSetMapping(name = "by-invoice", entities = {
        @EntityResult(entityClass = Inventory.class)})
})
@NamedNativeQueries({
    @NamedNativeQuery(name = "Inventory.findBestSellers",
            query = "SELECT i.*, COUNT(li.ISBN) AS NumberOfOrders FROM inventory AS i "
            + "INNER JOIN lineItem li ON i.ISBN = li.ISBN WHERE i.removalStatus = 0 GROUP BY li.ISBN "
            + "ORDER BY NumberOfOrders DESC LIMIT 4",
            resultClass = Inventory.class),
    @NamedNativeQuery(name = "Inventory.findFeaturedTitle",
            query = "SELECT i.* FROM inventory AS i WHERE i.removalStatus = 0 ORDER BY RAND() LIMIT 4",
            resultClass = Inventory.class),
    @NamedNativeQuery(name = "Inventory.findByPartialValue",
            query = "SELECT i.* FROM inventory AS i WHERE i.title = :searchValue AND i.removalStatus = 0",
            resultClass = Inventory.class),
    @NamedNativeQuery(name = "Inventory.findByInvoice",
            query = "SELECT * from Invoice AS i\n"
            + "LEFT JOIN lineItem li\n"
            + "ON i.id = li.invoiceId\n"
            + "LEFT JOIN inventory iv\n"
            + "ON li.ISBN = iv.ISBN\n"
            + "WHERE i.id = ? AND i.userId = ?\n"
            + "ORDER BY iv.title",
            resultClass = Inventory.class)
})
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Inventory.findAll", query = "SELECT i FROM Inventory i"),
    @NamedQuery(name = "Inventory.findJustArrived", query = "SELECT i FROM Inventory i WHERE i.removalStatus = 0 ORDER BY i.createdAt DESC"),
    @NamedQuery(name = "Inventory.findByIsbnAdmin", query = "SELECT i FROM Inventory i WHERE i.isbn = :isbn"),
    @NamedQuery(name = "Inventory.findByIsbn", query = "SELECT i FROM Inventory i WHERE i.isbn = :isbn AND i.removalStatus = 0"),
    @NamedQuery(name = "Inventory.findByIsbnList", query = "SELECT i FROM Inventory i WHERE i.isbn IN :isbnList AND i.removalStatus = 0"),
    @NamedQuery(name = "Inventory.findByGenre", query = "SELECT i FROM Inventory i WHERE i.genreId = :genreId AND i.removalStatus = 0"),
    @NamedQuery(name = "Inventory.findByTitle", query = "SELECT i FROM Inventory i WHERE i.title = :title AND i.removalStatus = 0"),
    @NamedQuery(name = "Inventory.findSearch", query = "SELECT i FROM Inventory i WHERE i.title LIKE :searchValue OR i.author LIKE :searchValue AND i.removalStatus = 0"),
    @NamedQuery(name = "Inventory.findByAuthor", query = "SELECT i FROM Inventory i WHERE i.author = :author AND i.removalStatus = 0"),
    @NamedQuery(name = "Inventory.findByPublisher", query = "SELECT i FROM Inventory i WHERE i.publisher = :publisher AND i.removalStatus = 0"),
    @NamedQuery(name = "Inventory.findByRemovalStatus", query = "SELECT i FROM Inventory i WHERE i.removalStatus = :removalStatus"),
    @NamedQuery(name = "Inventory.count", query = "Select Count(e) from Inventory e")})
public class Inventory implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "ISBN", nullable = false, length = 30)
    private String isbn;

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "title", nullable = false, length = 255)
    private String title;

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "author", nullable = false, length = 255)
    private String author;

    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "description", nullable = false)
    private byte[] description;

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "publisher", nullable = false, length = 255)
    private String publisher;

    @Basic(optional = false)
    @NotNull
    @Column(name = "numberOfPages", nullable = false)
    private int numberOfPages;

    @Size(max = 255)
    @Column(name = "cover", length = 255)
    private String cover;

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "wholesalePrice", nullable = false, precision = 10, scale = 2)
    private BigDecimal wholesalePrice;

    @Basic(optional = false)
    @NotNull
    @Column(name = "listPrice", nullable = false, precision = 10, scale = 2)
    private BigDecimal listPrice;

    @Basic(optional = false)
    @NotNull
    @Column(name = "removalStatus", nullable = false)
    private boolean removalStatus;

    @Basic(optional = false)
    @NotNull
    @Column(name = "createdAt", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @JoinColumn(name = "genreId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private Genre genreId;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "isbn")
    private Collection<Wishlist> wishlistCollection;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "isbn")
    private Collection<Review> reviewCollection;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "isbn")
    private Collection<LineItem> lineItemCollection;

    public Inventory() {
    }

    public Inventory(String isbn) {
        this.isbn = isbn;
    }

    public Inventory(String isbn, String title, String author, String publisher, int numberOfPages, byte[] description, BigDecimal wholesalePrice, BigDecimal listPrice, boolean removalStatus, Date createdAt) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.numberOfPages = numberOfPages;
        this.description = description;
        this.wholesalePrice = wholesalePrice;
        this.listPrice = listPrice;
        this.removalStatus = removalStatus;
        this.createdAt = createdAt;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public int getNumberOfPages() {
        return numberOfPages;
    }

    public void setNumberOfPages(int numberOfPages) {
        this.numberOfPages = numberOfPages;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public BigDecimal getWholesalePrice() {
        return wholesalePrice;
    }

    public void setWholesalePrice(BigDecimal wholesalePrice) {
        this.wholesalePrice = wholesalePrice;
    }

    public BigDecimal getListPrice() {
        return listPrice;
    }

    public void setListPrice(BigDecimal listPrice) {
        this.listPrice = listPrice;
    }

    public boolean getRemovalStatus() {
        return removalStatus;
    }

    public void setRemovalStatus(boolean removalStatus) {
        this.removalStatus = removalStatus;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Genre getGenreId() {
        return genreId;
    }

    public void setGenreId(Genre genreId) {
        this.genreId = genreId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (isbn != null ? isbn.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Inventory)) {
            return false;
        }
        Inventory other = (Inventory) object;
        if ((this.isbn == null && other.isbn != null) || (this.isbn != null && !this.isbn.equals(other.isbn))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.dmkiak.beans.Inventory[ isbn=" + isbn + " ]";
    }

    @XmlTransient
    public Collection<LineItem> getLineItemCollection() {
        return lineItemCollection;
    }

    public void setLineItemCollection(Collection<LineItem> lineItemCollection) {
        this.lineItemCollection = lineItemCollection;
    }

    public byte[] getDescription() {
        return description;
    }

    public void setDescription(byte[] description) {
        this.description = description;
    }

    @XmlTransient
    public Collection<Review> getReviewCollection() {
        return reviewCollection;
    }

    public void setReviewCollection(Collection<Review> reviewCollection) {
        this.reviewCollection = reviewCollection;
    }

    @XmlTransient
    public Collection<Wishlist> getWishlistCollection() {
        return wishlistCollection;
    }

    public void setWishlistCollection(Collection<Wishlist> wishlistCollection) {
        this.wishlistCollection = wishlistCollection;
    }
}
