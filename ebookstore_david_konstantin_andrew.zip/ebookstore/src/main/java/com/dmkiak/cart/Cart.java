package com.dmkiak.cart;

import com.dmkiak.beans.Inventory;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import org.apache.log4j.Logger;

/**
 * Cart bean
 * @author David Maignan <davidmaignan@gmail.com>
 */
public class Cart implements Serializable{   
   
    private ArrayList<Inventory> list;
    
    private int size;
    private BigDecimal pst;
    private BigDecimal gst;

    public Cart() {
        list = new ArrayList<>();
    }

    public BigDecimal getPst() {
        return pst;
    }

    public void setPst(BigDecimal pst) {
        this.pst = pst;
    }

    public BigDecimal getGst() {
        return gst;
    }

    public void setGst(BigDecimal gst) {
        this.gst = gst;
    }
    
    public boolean addInventory(Inventory book){
        if(! list.contains(book)){
            return list.add(book);
        }
        
        return false;
    }
    
    public boolean remove(Inventory book){
        return list.remove(book);
    }
    
    public void removeAll(){
        list.clear();
    }
    
    public int getSize(){
        return list.size();
    }

    public ArrayList<Inventory> getList() {
        return list;
    }
    
    public BigDecimal getPstTotal() {    
        return new BigDecimal(0);
        //return this.getTotal().multiply(this.getPst()).setScale(2, BigDecimal.ROUND_HALF_EVEN);
    }
    
    public BigDecimal getGstTotal() {
        return this.getTotal().multiply(this.getGst()).setScale(2, BigDecimal.ROUND_HALF_EVEN);
    }
    
    public BigDecimal getTotal() {
        BigDecimal total = new BigDecimal("0.00");
        
        for (Inventory inventory : list) {
            total = total.add(inventory.getListPrice());
        }
        
        return total.setScale(2, BigDecimal.ROUND_HALF_EVEN);
    }
    
    public BigDecimal getGrandTotal() {
        return this.getTotal().add(this.getGstTotal()).add(this.getPstTotal()).setScale(2, BigDecimal.ROUND_HALF_EVEN);
    }

    @Override
    public String toString() {
        return "Cart{" + "list=" + list + ", size=" + this.getSize() + '}';
    }
}
