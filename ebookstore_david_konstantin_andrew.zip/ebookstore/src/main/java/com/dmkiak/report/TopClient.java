package com.dmkiak.report;

import com.dmkiak.beans.User;
import java.math.BigDecimal;

/**
 * POJO to manage top client report
 * 
 * @author David Maignan <davidmaignan@gmail.com>
 */
final public class TopClient {
    private BigDecimal totalNet;
    private Long totalOrder;
    private String username;

    public TopClient(String username, BigDecimal totalNet, Long totalOrder) {
        this.username = username;
        this.totalNet = totalNet;
        this.totalOrder = totalOrder;
    }

    public String getUsername() {
        return username;
    }

    public BigDecimal getTotalNet() {
        return totalNet;
    }

    public Long getTotalOrder() {
        return totalOrder;
    }

    @Override
    public String toString() {
        return "TopClient{" + "totalNet=" + totalNet + ", totalOrder=" + totalOrder + '}';
    }
}
