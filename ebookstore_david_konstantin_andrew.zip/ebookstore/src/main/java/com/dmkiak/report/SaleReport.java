package com.dmkiak.report;

import java.math.BigDecimal;

/**
 * POJO to graph report
 * 
 * @author David Maignan <davidmaignan@gmail.com>
 */
public class SaleReport implements SaleReportInterface{
    private Integer week;
    private BigDecimal amount;
    private String genre;

    public SaleReport(String genre, BigDecimal amount, String week) {
        this.amount = amount;
        this.genre = genre;
        this.week = Integer.valueOf(week);
    }

    public Integer getWeek() {
        return week;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "SaleReport{" + "week=" + week + ", amount=" + amount + ", genre=" + genre + '}';
    }
}
