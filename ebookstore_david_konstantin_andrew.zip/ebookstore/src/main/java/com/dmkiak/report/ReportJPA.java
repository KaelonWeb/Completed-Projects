package com.dmkiak.report;

import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;
import org.apache.log4j.Logger;

/**
 * Report JPA
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class ReportJPA {

    private static final Logger logger = Logger.getLogger(ReportJPA.class);

    @PersistenceContext(name = "ebookstorePU")
    private EntityManager entityManager;

    @Resource
    private UserTransaction userTransaction;

    @Inject
    ReportService reportService;

    public String salesByGenre() {
        Query query = entityManager.createNamedQuery("Invoice.findSalesByGenre");
        List result = query.getResultList();
        logger.debug(result.size());
        
        return reportService.generateAreaData(result, "morris-area-chart");
    }
}
