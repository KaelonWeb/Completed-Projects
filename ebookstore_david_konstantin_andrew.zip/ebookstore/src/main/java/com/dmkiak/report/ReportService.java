/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dmkiak.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import org.apache.log4j.Logger;

/**
 * Service to generate data for reports
 *
 * @author david
 */
@Named
@RequestScoped
public class ReportService {

    private static final Logger logger = Logger.getLogger(ReportJPA.class);

    private Map<Integer, ArrayList<SaleReport>> reportList = new HashMap<>();
    private ArrayList<Integer> keys = new ArrayList<>();
    private String element;
    private Set<String> labelList = new HashSet<>();

    public String generateAreaData(List<SaleReport> list, String element) {
        this.element = element;

        for (SaleReport saleReport : list) {
            logger.debug(saleReport);

            if (reportList.get(saleReport.getWeek()) == null) {
                ArrayList<SaleReport> tmp = new ArrayList<>();
                tmp.add(saleReport);
                reportList.put(saleReport.getWeek(), tmp);
            } else {
                reportList.get(saleReport.getWeek()).add(saleReport);
            }
        }

        logger.debug(reportList);

        return this.generateJScript();

//        StringBuilder builder = new StringBuilder();
//        
//        builder.append(
//                String.format("$(function() { Morris.Area({element: '%s',", element)
//        );
//        
//        builder.append("data: [");
//        
//        for (Map.Entry<Integer, ArrayList<SaleReport>> entrySet : reportList.entrySet()) {
//            Integer key = entrySet.getKey();
//            
//            ArrayList<SaleReport> value = entrySet.getValue();
//            String valueString = String.format("Cooking: 2666, Poetry: null, Comic: 2647 ");
//            
//            String data = String.format("{period: '%d', %s}", key);
//            builder.append(data);
//        }
//        
//        builder.append("],");
//        
//        builder.append("xkey: 'period',\n" +
//"        ykeys: ['Cooking', 'Poetry', 'Comic'],\n" +
//"        labels: ['Fiction', 'Food & Wine', 'Comic'],\n" +
//"        pointSize: 2,\n" +
//"        hideHover: 'auto',\n" +
//"        resize: true");
//        
//        return builder.toString();
    }

    private String generateJScript() {
        StringBuilder builder = new StringBuilder();

        builder.append(String.format("Morris.Area({element: '%s', ", this.element));
        builder.append(String.format("data: [%s], ", this.getData()));
        
        logger.error(this.getLabels());

        builder.append("   xkey: 'period',\n"
                + "        ykeys: [" + this.getLabels() + "],\n"
                + "        labels: [" + this.getLabels() + "],\n"
                + "        pointSize: 2,\n"
                + "        hideHover: 'auto',\n"
                + "        resize: true });");

        return builder.toString();
    }
    
    private String getData() {
        String format = "{period: '%d', %s }, ";
        
        StringBuilder builder = new StringBuilder();
        
        for (Map.Entry<Integer, ArrayList<SaleReport>> entrySet : reportList.entrySet()) {
            StringBuilder  reportStringBuilder = new StringBuilder();
            
            for (SaleReport report : entrySet.getValue()) {
                labelList.add(report.getGenre());
                reportStringBuilder.append(String.format("'%s': %.2f, ", report.getGenre(), report.getAmount()));
            }
            //Cooking: 2666, Poetry: null, Comic: 2647
            
            builder.append(String.format(format, entrySet.getKey(), reportStringBuilder.toString()));
            
            
        }
        
        logger.debug(builder);
        
        return builder.toString();
    }
    
    private String getLabels(){
        StringBuilder builder = new StringBuilder();
        
        labelList.stream().forEach((label) -> {
            builder.append("'").append(label).append("'").append(", ");
        });
        
        int length = builder.toString().length();
        
        return builder.toString().substring(0, length - 2);
    }

    public Map<Integer, ArrayList<SaleReport>> getReportList() {
        return reportList;
    }
}
