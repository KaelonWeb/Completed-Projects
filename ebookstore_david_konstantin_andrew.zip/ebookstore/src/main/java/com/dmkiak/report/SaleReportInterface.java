package com.dmkiak.report;

/**
 * Interface for report generated file
 * 
 * @author David Maignan <davidmaignan@gmail.com>
 */
public interface SaleReportInterface {
    
}
