package com.dmkiak.report;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import org.apache.log4j.Logger;

/**
 * Service to generate file for report
 * @author david
 */
@Named
@RequestScoped
public class ReportFileService {
    private static final Logger logger = Logger.getLogger(ReportFileService.class);
    
    private FileOutputStream fos;
    private DataOutputStream dos;
    
    private ExternalContext externalContext;
    
    public void generateScript() throws FileNotFoundException, IOException {
        externalContext = FacesContext.getCurrentInstance().getExternalContext();
        
        String contextPath = externalContext.getApplicationContextPath();
        String filename = "test.js";
        String filePath = String.format("%s/resources/js/%s", contextPath, filename);
        logger.debug(filePath);
        
        fos = new FileOutputStream(new File(filePath));
        dos = new DataOutputStream(fos);
        dos.writeChars("console.log('test')");
        dos.close();
    }
    
}
