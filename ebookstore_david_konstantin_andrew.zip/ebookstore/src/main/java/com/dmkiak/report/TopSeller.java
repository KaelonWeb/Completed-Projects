package com.dmkiak.report;

import java.sql.Timestamp;

/**
 * POJO to manage top seller display
 * 
 * @author David Maignan <davidmaignan@gmail.com>
 */
final public class TopSeller {
    private final Long total;
    private final Integer invoiceId;
    private final String isbn;
    private String title;
    private final Timestamp createdAt;

    public TopSeller(Integer invoiceId, Long total, String isbn, String title, Timestamp createdAt) {
        this.invoiceId = invoiceId;
        this.total = total;
        this.isbn = isbn;
        this.title = title;
        this.createdAt = createdAt;
    }

    public Long getTotal() {
        return total;
    }

    public Integer getInvoiceId() {
        return invoiceId;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    @Override
    public String toString() {
        return "SaleReport{total=" + total + ", invoiceId=" + invoiceId + ", isbn=" + isbn + ", createdAt=" + createdAt + '}';
    }
}
