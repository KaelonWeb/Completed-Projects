package com.dmkiak.cookie;

import java.util.HashMap;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.servlet.http.Cookie;
import org.apache.log4j.Logger;

/**
 *
 * @author david
 */
@Named
@RequestScoped
public class CookieManager {
    
    public Cookie getValueByName(String name) {
        FacesContext context = FacesContext.getCurrentInstance();
        Object cookie = context.getExternalContext().getRequestCookieMap().get(name);
        
        if (cookie != null) {
            return (Cookie)cookie;
        }
        
        return null;
    }
    
    public void writeCookie(String name, String value, HashMap<String, Object> parameters) {
        FacesContext.getCurrentInstance().getExternalContext().addResponseCookie(name, value, parameters);
    }
    
    public void appendCookie(String name, String value) {
        
        HashMap<String, Object> parameters = new HashMap<>();
        
        parameters.put("maxAge", 3600 * 24 * 30);
        
        Cookie cookie = getValueByName(name);
        
        if(cookie == null) {
            writeCookie(name, value, parameters);
        }else if (! cookie.getValue().matches(value)){
            writeCookie(name, cookie.getValue() + ":" + value, parameters);
        }
    }
}
