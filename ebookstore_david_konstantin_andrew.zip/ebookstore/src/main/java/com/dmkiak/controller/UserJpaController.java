package com.dmkiak.controller;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.dmkiak.beans.Role;
import com.dmkiak.beans.Client;
import com.dmkiak.beans.Review;
import java.util.ArrayList;
import java.util.Collection;
import com.dmkiak.beans.Invoice;
import com.dmkiak.beans.User;
import com.dmkiak.beans.Wishlist;
import com.dmkiak.controller.exceptions.IllegalOrphanException;
import com.dmkiak.controller.exceptions.NonexistentEntityException;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

/**
 * UserJPAController - Manage persistence for User bean
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class UserJpaController implements Serializable {

    @Resource
    private UserTransaction utx;

    @PersistenceContext
    private EntityManager em;

    public void create(User user) throws RollbackFailureException, Exception {
        if (user.getReviewCollection() == null) {
            user.setReviewCollection(new ArrayList<Review>());
        }
        if (user.getInvoiceCollection() == null) {
            user.setInvoiceCollection(new ArrayList<Invoice>());
        }
        if (user.getWishlistCollection() == null) {
            user.setWishlistCollection(new ArrayList<Wishlist>());
        }
        
        try {
            utx.begin();
            
            Role roleId = user.getRoleId();
            if (roleId != null) {
                roleId = em.getReference(roleId.getClass(), roleId.getId());
                user.setRoleId(roleId);
            }
            Client client = user.getClient();
            if (client != null) {
                client = em.getReference(client.getClass(), client.getUserId());
                user.setClient(client);
            }
            Collection<Review> attachedReviewCollection = new ArrayList<Review>();
            for (Review reviewCollectionReviewToAttach : user.getReviewCollection()) {
                reviewCollectionReviewToAttach = em.getReference(reviewCollectionReviewToAttach.getClass(), reviewCollectionReviewToAttach.getId());
                attachedReviewCollection.add(reviewCollectionReviewToAttach);
            }
            user.setReviewCollection(attachedReviewCollection);
            Collection<Invoice> attachedInvoiceCollection = new ArrayList<Invoice>();
            for (Invoice invoiceCollectionInvoiceToAttach : user.getInvoiceCollection()) {
                invoiceCollectionInvoiceToAttach = em.getReference(invoiceCollectionInvoiceToAttach.getClass(), invoiceCollectionInvoiceToAttach.getId());
                attachedInvoiceCollection.add(invoiceCollectionInvoiceToAttach);
            }
            user.setInvoiceCollection(attachedInvoiceCollection);
            Collection<Wishlist> attachedWishlistCollection = new ArrayList<Wishlist>();
            for (Wishlist wishlistCollectionWishlistToAttach : user.getWishlistCollection()) {
                wishlistCollectionWishlistToAttach = em.getReference(wishlistCollectionWishlistToAttach.getClass(), wishlistCollectionWishlistToAttach.getId());
                attachedWishlistCollection.add(wishlistCollectionWishlistToAttach);
            }
            user.setWishlistCollection(attachedWishlistCollection);
            em.persist(user);
            if (roleId != null) {
                roleId.getUserCollection().add(user);
                roleId = em.merge(roleId);
            }
            if (client != null) {
                User oldUserOfClient = client.getUser();
                if (oldUserOfClient != null) {
                    oldUserOfClient.setClient(null);
                    oldUserOfClient = em.merge(oldUserOfClient);
                }
                client.setUser(user);
                client = em.merge(client);
            }
            for (Review reviewCollectionReview : user.getReviewCollection()) {
                User oldUserIdOfReviewCollectionReview = reviewCollectionReview.getUserId();
                reviewCollectionReview.setUserId(user);
                reviewCollectionReview = em.merge(reviewCollectionReview);
                if (oldUserIdOfReviewCollectionReview != null) {
                    oldUserIdOfReviewCollectionReview.getReviewCollection().remove(reviewCollectionReview);
                    oldUserIdOfReviewCollectionReview = em.merge(oldUserIdOfReviewCollectionReview);
                }
            }
            for (Invoice invoiceCollectionInvoice : user.getInvoiceCollection()) {
                User oldUserIdOfInvoiceCollectionInvoice = invoiceCollectionInvoice.getUserId();
                invoiceCollectionInvoice.setUserId(user);
                invoiceCollectionInvoice = em.merge(invoiceCollectionInvoice);
                if (oldUserIdOfInvoiceCollectionInvoice != null) {
                    oldUserIdOfInvoiceCollectionInvoice.getInvoiceCollection().remove(invoiceCollectionInvoice);
                    oldUserIdOfInvoiceCollectionInvoice = em.merge(oldUserIdOfInvoiceCollectionInvoice);
                }
            }
            for (Wishlist wishlistCollectionWishlist : user.getWishlistCollection()) {
                User oldUserIdOfWishlistCollectionWishlist = wishlistCollectionWishlist.getUserId();
                wishlistCollectionWishlist.setUserId(user);
                wishlistCollectionWishlist = em.merge(wishlistCollectionWishlist);
                if (oldUserIdOfWishlistCollectionWishlist != null) {
                    oldUserIdOfWishlistCollectionWishlist.getWishlistCollection().remove(wishlistCollectionWishlist);
                    oldUserIdOfWishlistCollectionWishlist = em.merge(oldUserIdOfWishlistCollectionWishlist);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                // em.close();
            }
        }
    }

    public void edit(User user) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        
        try {
            utx.begin();
            
            User persistentUser = em.find(User.class, user.getId());
            Role roleIdOld = persistentUser.getRoleId();
            Role roleIdNew = user.getRoleId();
            Client clientOld = persistentUser.getClient();
            Client clientNew = user.getClient();
            Collection<Review> reviewCollectionOld = persistentUser.getReviewCollection();
            Collection<Review> reviewCollectionNew = user.getReviewCollection();
            Collection<Invoice> invoiceCollectionOld = persistentUser.getInvoiceCollection();
            Collection<Invoice> invoiceCollectionNew = user.getInvoiceCollection();
            Collection<Wishlist> wishlistCollectionOld = persistentUser.getWishlistCollection();
            Collection<Wishlist> wishlistCollectionNew = user.getWishlistCollection();
            List<String> illegalOrphanMessages = null;
            if (clientOld != null && !clientOld.equals(clientNew)) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("You must retain Client " + clientOld + " since its user field is not nullable.");
            }
            for (Review reviewCollectionOldReview : reviewCollectionOld) {
                if (!reviewCollectionNew.contains(reviewCollectionOldReview)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Review " + reviewCollectionOldReview + " since its userId field is not nullable.");
                }
            }
            for (Invoice invoiceCollectionOldInvoice : invoiceCollectionOld) {
                if (!invoiceCollectionNew.contains(invoiceCollectionOldInvoice)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Invoice " + invoiceCollectionOldInvoice + " since its userId field is not nullable.");
                }
            }
            for (Wishlist wishlistCollectionOldWishlist : wishlistCollectionOld) {
                if (!wishlistCollectionNew.contains(wishlistCollectionOldWishlist)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Wishlist " + wishlistCollectionOldWishlist + " since its userId field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (roleIdNew != null) {
                roleIdNew = em.getReference(roleIdNew.getClass(), roleIdNew.getId());
                user.setRoleId(roleIdNew);
            }
            if (clientNew != null) {
                clientNew = em.getReference(clientNew.getClass(), clientNew.getUserId());
                user.setClient(clientNew);
            }
            Collection<Review> attachedReviewCollectionNew = new ArrayList<Review>();
            for (Review reviewCollectionNewReviewToAttach : reviewCollectionNew) {
                reviewCollectionNewReviewToAttach = em.getReference(reviewCollectionNewReviewToAttach.getClass(), reviewCollectionNewReviewToAttach.getId());
                attachedReviewCollectionNew.add(reviewCollectionNewReviewToAttach);
            }
            reviewCollectionNew = attachedReviewCollectionNew;
            user.setReviewCollection(reviewCollectionNew);
            Collection<Invoice> attachedInvoiceCollectionNew = new ArrayList<Invoice>();
            for (Invoice invoiceCollectionNewInvoiceToAttach : invoiceCollectionNew) {
                invoiceCollectionNewInvoiceToAttach = em.getReference(invoiceCollectionNewInvoiceToAttach.getClass(), invoiceCollectionNewInvoiceToAttach.getId());
                attachedInvoiceCollectionNew.add(invoiceCollectionNewInvoiceToAttach);
            }
            invoiceCollectionNew = attachedInvoiceCollectionNew;
            user.setInvoiceCollection(invoiceCollectionNew);
            Collection<Wishlist> attachedWishlistCollectionNew = new ArrayList<Wishlist>();
            for (Wishlist wishlistCollectionNewWishlistToAttach : wishlistCollectionNew) {
                wishlistCollectionNewWishlistToAttach = em.getReference(wishlistCollectionNewWishlistToAttach.getClass(), wishlistCollectionNewWishlistToAttach.getId());
                attachedWishlistCollectionNew.add(wishlistCollectionNewWishlistToAttach);
            }
            wishlistCollectionNew = attachedWishlistCollectionNew;
            user.setWishlistCollection(wishlistCollectionNew);
            user = em.merge(user);
            if (roleIdOld != null && !roleIdOld.equals(roleIdNew)) {
                roleIdOld.getUserCollection().remove(user);
                roleIdOld = em.merge(roleIdOld);
            }
            if (roleIdNew != null && !roleIdNew.equals(roleIdOld)) {
                roleIdNew.getUserCollection().add(user);
                roleIdNew = em.merge(roleIdNew);
            }
            if (clientNew != null && !clientNew.equals(clientOld)) {
                User oldUserOfClient = clientNew.getUser();
                if (oldUserOfClient != null) {
                    oldUserOfClient.setClient(null);
                    oldUserOfClient = em.merge(oldUserOfClient);
                }
                clientNew.setUser(user);
                clientNew = em.merge(clientNew);
            }
            for (Review reviewCollectionNewReview : reviewCollectionNew) {
                if (!reviewCollectionOld.contains(reviewCollectionNewReview)) {
                    User oldUserIdOfReviewCollectionNewReview = reviewCollectionNewReview.getUserId();
                    reviewCollectionNewReview.setUserId(user);
                    reviewCollectionNewReview = em.merge(reviewCollectionNewReview);
                    if (oldUserIdOfReviewCollectionNewReview != null && !oldUserIdOfReviewCollectionNewReview.equals(user)) {
                        oldUserIdOfReviewCollectionNewReview.getReviewCollection().remove(reviewCollectionNewReview);
                        oldUserIdOfReviewCollectionNewReview = em.merge(oldUserIdOfReviewCollectionNewReview);
                    }
                }
            }
            for (Invoice invoiceCollectionNewInvoice : invoiceCollectionNew) {
                if (!invoiceCollectionOld.contains(invoiceCollectionNewInvoice)) {
                    User oldUserIdOfInvoiceCollectionNewInvoice = invoiceCollectionNewInvoice.getUserId();
                    invoiceCollectionNewInvoice.setUserId(user);
                    invoiceCollectionNewInvoice = em.merge(invoiceCollectionNewInvoice);
                    if (oldUserIdOfInvoiceCollectionNewInvoice != null && !oldUserIdOfInvoiceCollectionNewInvoice.equals(user)) {
                        oldUserIdOfInvoiceCollectionNewInvoice.getInvoiceCollection().remove(invoiceCollectionNewInvoice);
                        oldUserIdOfInvoiceCollectionNewInvoice = em.merge(oldUserIdOfInvoiceCollectionNewInvoice);
                    }
                }
            }
            for (Wishlist wishlistCollectionNewWishlist : wishlistCollectionNew) {
                if (!wishlistCollectionOld.contains(wishlistCollectionNewWishlist)) {
                    User oldUserIdOfWishlistCollectionNewWishlist = wishlistCollectionNewWishlist.getUserId();
                    wishlistCollectionNewWishlist.setUserId(user);
                    wishlistCollectionNewWishlist = em.merge(wishlistCollectionNewWishlist);
                    if (oldUserIdOfWishlistCollectionNewWishlist != null && !oldUserIdOfWishlistCollectionNewWishlist.equals(user)) {
                        oldUserIdOfWishlistCollectionNewWishlist.getWishlistCollection().remove(wishlistCollectionNewWishlist);
                        oldUserIdOfWishlistCollectionNewWishlist = em.merge(oldUserIdOfWishlistCollectionNewWishlist);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = user.getId();
                if (findUser(id) == null) {
                    throw new NonexistentEntityException("The user with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                // em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        
        try {
            utx.begin();
            
            User user;
            try {
                user = em.getReference(User.class, id);
                user.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The user with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Client clientOrphanCheck = user.getClient();
            if (clientOrphanCheck != null) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This User (" + user + ") cannot be destroyed since the Client " + clientOrphanCheck + " in its client field has a non-nullable user field.");
            }
            Collection<Review> reviewCollectionOrphanCheck = user.getReviewCollection();
            for (Review reviewCollectionOrphanCheckReview : reviewCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This User (" + user + ") cannot be destroyed since the Review " + reviewCollectionOrphanCheckReview + " in its reviewCollection field has a non-nullable userId field.");
            }
            Collection<Invoice> invoiceCollectionOrphanCheck = user.getInvoiceCollection();
            for (Invoice invoiceCollectionOrphanCheckInvoice : invoiceCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This User (" + user + ") cannot be destroyed since the Invoice " + invoiceCollectionOrphanCheckInvoice + " in its invoiceCollection field has a non-nullable userId field.");
            }
            Collection<Wishlist> wishlistCollectionOrphanCheck = user.getWishlistCollection();
            for (Wishlist wishlistCollectionOrphanCheckWishlist : wishlistCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This User (" + user + ") cannot be destroyed since the Wishlist " + wishlistCollectionOrphanCheckWishlist + " in its wishlistCollection field has a non-nullable userId field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Role roleId = user.getRoleId();
            if (roleId != null) {
                roleId.getUserCollection().remove(user);
                roleId = em.merge(roleId);
            }
            em.remove(user);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                // em.close();
            }
        }
    }

    public List<User> findUserEntities() {
        return findUserEntities(true, -1, -1);
    }

    public List<User> findUserEntities(int maxResults, int firstResult) {
        return findUserEntities(false, maxResults, firstResult);
    }

    private List<User> findUserEntities(boolean all, int maxResults, int firstResult) {
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(User.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            // em.close();
        }
    }

    public User findUser(Integer id) {
        try {
            return em.find(User.class, id);
        } finally {
            // em.close();
        }
    }

    public int getUserCount() {
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<User> rt = cq.from(User.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            // em.close();
        }
    }
}
