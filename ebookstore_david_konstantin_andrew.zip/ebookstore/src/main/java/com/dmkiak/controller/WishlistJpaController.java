package com.dmkiak.controller;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.dmkiak.beans.Inventory;
import com.dmkiak.beans.User;
import com.dmkiak.beans.Wishlist;
import com.dmkiak.controller.exceptions.NonexistentEntityException;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

/**
 * WishListJPAController - Manage persistence for Wishlist bean
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class WishlistJpaController implements Serializable {
    
    @Resource
    private UserTransaction utx;

    @PersistenceContext
    private EntityManager em;

    public void create(Wishlist wishlist) throws RollbackFailureException, Exception {
        try {
            utx.begin();
            
            Inventory isbn = wishlist.getIsbn();
            if (isbn != null) {
                isbn = em.getReference(isbn.getClass(), isbn.getIsbn());
                wishlist.setIsbn(isbn);
            }
            User userId = wishlist.getUserId();
            if (userId != null) {
                userId = em.getReference(userId.getClass(), userId.getId());
                wishlist.setUserId(userId);
            }
            em.persist(wishlist);
            if (isbn != null) {
                isbn.getWishlistCollection().add(wishlist);
                isbn = em.merge(isbn);
            }
            if (userId != null) {
                userId.getWishlistCollection().add(wishlist);
                userId = em.merge(userId);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void edit(Wishlist wishlist) throws NonexistentEntityException, RollbackFailureException, Exception {
        try {
            utx.begin();
            
            Wishlist persistentWishlist = em.find(Wishlist.class, wishlist.getId());
            Inventory isbnOld = persistentWishlist.getIsbn();
            Inventory isbnNew = wishlist.getIsbn();
            User userIdOld = persistentWishlist.getUserId();
            User userIdNew = wishlist.getUserId();
            if (isbnNew != null) {
                isbnNew = em.getReference(isbnNew.getClass(), isbnNew.getIsbn());
                wishlist.setIsbn(isbnNew);
            }
            if (userIdNew != null) {
                userIdNew = em.getReference(userIdNew.getClass(), userIdNew.getId());
                wishlist.setUserId(userIdNew);
            }
            wishlist = em.merge(wishlist);
            if (isbnOld != null && !isbnOld.equals(isbnNew)) {
                isbnOld.getWishlistCollection().remove(wishlist);
                isbnOld = em.merge(isbnOld);
            }
            if (isbnNew != null && !isbnNew.equals(isbnOld)) {
                isbnNew.getWishlistCollection().add(wishlist);
                isbnNew = em.merge(isbnNew);
            }
            if (userIdOld != null && !userIdOld.equals(userIdNew)) {
                userIdOld.getWishlistCollection().remove(wishlist);
                userIdOld = em.merge(userIdOld);
            }
            if (userIdNew != null && !userIdNew.equals(userIdOld)) {
                userIdNew.getWishlistCollection().add(wishlist);
                userIdNew = em.merge(userIdNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = wishlist.getId();
                if (findWishlist(id) == null) {
                    throw new NonexistentEntityException("The wishlist with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        try {
            utx.begin();
            
            Wishlist wishlist;
            try {
                wishlist = em.getReference(Wishlist.class, id);
                wishlist.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The wishlist with id " + id + " no longer exists.", enfe);
            }
            Inventory isbn = wishlist.getIsbn();
            if (isbn != null) {
                isbn.getWishlistCollection().remove(wishlist);
                isbn = em.merge(isbn);
            }
            User userId = wishlist.getUserId();
            if (userId != null) {
                userId.getWishlistCollection().remove(wishlist);
                userId = em.merge(userId);
            }
            em.remove(wishlist);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public List<Wishlist> findWishlistEntities() {
        return findWishlistEntities(true, -1, -1);
    }

    public List<Wishlist> findWishlistEntities(int maxResults, int firstResult) {
        return findWishlistEntities(false, maxResults, firstResult);
    }

    private List<Wishlist> findWishlistEntities(boolean all, int maxResults, int firstResult) {
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Wishlist.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            //em.close();
        }
    }

    public Wishlist findWishlist(Integer id) {
        try {
            return em.find(Wishlist.class, id);
        } finally {
            //em.close();
        }
    }

    public int getWishlistCount() {
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Wishlist> rt = cq.from(Wishlist.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            //em.close();
        }
    }
}
