/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dmkiak.controller;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.dmkiak.beans.Client;
import com.dmkiak.beans.Title;
import com.dmkiak.controller.exceptions.IllegalOrphanException;
import com.dmkiak.controller.exceptions.NonexistentEntityException;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
public class TitleJpaController implements Serializable {

    public TitleJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Title title) throws RollbackFailureException, Exception {
        if (title.getClientCollection() == null) {
            title.setClientCollection(new ArrayList<Client>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Collection<Client> attachedClientCollection = new ArrayList<Client>();
            for (Client clientCollectionClientToAttach : title.getClientCollection()) {
                clientCollectionClientToAttach = em.getReference(clientCollectionClientToAttach.getClass(), clientCollectionClientToAttach.getUserId());
                attachedClientCollection.add(clientCollectionClientToAttach);
            }
            title.setClientCollection(attachedClientCollection);
            em.persist(title);
            for (Client clientCollectionClient : title.getClientCollection()) {
                Title oldTitleIdOfClientCollectionClient = clientCollectionClient.getTitleId();
                clientCollectionClient.setTitleId(title);
                clientCollectionClient = em.merge(clientCollectionClient);
                if (oldTitleIdOfClientCollectionClient != null) {
                    oldTitleIdOfClientCollectionClient.getClientCollection().remove(clientCollectionClient);
                    oldTitleIdOfClientCollectionClient = em.merge(oldTitleIdOfClientCollectionClient);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Title title) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Title persistentTitle = em.find(Title.class, title.getId());
            Collection<Client> clientCollectionOld = persistentTitle.getClientCollection();
            Collection<Client> clientCollectionNew = title.getClientCollection();
            List<String> illegalOrphanMessages = null;
            for (Client clientCollectionOldClient : clientCollectionOld) {
                if (!clientCollectionNew.contains(clientCollectionOldClient)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Client " + clientCollectionOldClient + " since its titleId field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Client> attachedClientCollectionNew = new ArrayList<Client>();
            for (Client clientCollectionNewClientToAttach : clientCollectionNew) {
                clientCollectionNewClientToAttach = em.getReference(clientCollectionNewClientToAttach.getClass(), clientCollectionNewClientToAttach.getUserId());
                attachedClientCollectionNew.add(clientCollectionNewClientToAttach);
            }
            clientCollectionNew = attachedClientCollectionNew;
            title.setClientCollection(clientCollectionNew);
            title = em.merge(title);
            for (Client clientCollectionNewClient : clientCollectionNew) {
                if (!clientCollectionOld.contains(clientCollectionNewClient)) {
                    Title oldTitleIdOfClientCollectionNewClient = clientCollectionNewClient.getTitleId();
                    clientCollectionNewClient.setTitleId(title);
                    clientCollectionNewClient = em.merge(clientCollectionNewClient);
                    if (oldTitleIdOfClientCollectionNewClient != null && !oldTitleIdOfClientCollectionNewClient.equals(title)) {
                        oldTitleIdOfClientCollectionNewClient.getClientCollection().remove(clientCollectionNewClient);
                        oldTitleIdOfClientCollectionNewClient = em.merge(oldTitleIdOfClientCollectionNewClient);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Short id = title.getId();
                if (findTitle(id) == null) {
                    throw new NonexistentEntityException("The title with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Short id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Title title;
            try {
                title = em.getReference(Title.class, id);
                title.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The title with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Client> clientCollectionOrphanCheck = title.getClientCollection();
            for (Client clientCollectionOrphanCheckClient : clientCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Title (" + title + ") cannot be destroyed since the Client " + clientCollectionOrphanCheckClient + " in its clientCollection field has a non-nullable titleId field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(title);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Title> findTitleEntities() {
        return findTitleEntities(true, -1, -1);
    }

    public List<Title> findTitleEntities(int maxResults, int firstResult) {
        return findTitleEntities(false, maxResults, firstResult);
    }

    private List<Title> findTitleEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Title.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Title findTitle(Short id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Title.class, id);
        } finally {
            em.close();
        }
    }

    public int getTitleCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Title> rt = cq.from(Title.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
