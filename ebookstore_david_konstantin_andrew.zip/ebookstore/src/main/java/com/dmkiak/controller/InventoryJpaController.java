package com.dmkiak.controller;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.dmkiak.beans.Genre;
import com.dmkiak.beans.Inventory;
import com.dmkiak.beans.LineItem;
import com.dmkiak.controller.exceptions.IllegalOrphanException;
import com.dmkiak.controller.exceptions.NonexistentEntityException;
import com.dmkiak.controller.exceptions.PreexistingEntityException;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

/**
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class InventoryJpaController implements Serializable {
    
    @Resource
    private UserTransaction utx;

    @PersistenceContext
    private EntityManager em;

    public void create(Inventory inventory) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (inventory.getLineItemCollection() == null) {
            inventory.setLineItemCollection(new ArrayList<LineItem>());
        }
        
        try {
            utx.begin();
            
            Genre genreId = inventory.getGenreId();
            if (genreId != null) {
                genreId = em.getReference(genreId.getClass(), genreId.getId());
                inventory.setGenreId(genreId);
            }
            Collection<LineItem> attachedLineItemCollection = new ArrayList<LineItem>();
            for (LineItem lineItemCollectionLineItemToAttach : inventory.getLineItemCollection()) {
                lineItemCollectionLineItemToAttach = em.getReference(lineItemCollectionLineItemToAttach.getClass(), lineItemCollectionLineItemToAttach.getId());
                attachedLineItemCollection.add(lineItemCollectionLineItemToAttach);
            }
            inventory.setLineItemCollection(attachedLineItemCollection);
            em.persist(inventory);
            if (genreId != null) {
                genreId.getInventoryCollection().add(inventory);
                genreId = em.merge(genreId);
            }
            for (LineItem lineItemCollectionLineItem : inventory.getLineItemCollection()) {
                Inventory oldIsbnOfLineItemCollectionLineItem = lineItemCollectionLineItem.getIsbn();
                lineItemCollectionLineItem.setIsbn(inventory);
                lineItemCollectionLineItem = em.merge(lineItemCollectionLineItem);
                if (oldIsbnOfLineItemCollectionLineItem != null) {
                    oldIsbnOfLineItemCollectionLineItem.getLineItemCollection().remove(lineItemCollectionLineItem);
                    oldIsbnOfLineItemCollectionLineItem = em.merge(oldIsbnOfLineItemCollectionLineItem);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findInventory(inventory.getIsbn()) != null) {
                throw new PreexistingEntityException("Inventory " + inventory + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void edit(Inventory inventory) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        
        try {
            utx.begin();
            
            Inventory persistentInventory = em.find(Inventory.class, inventory.getIsbn());
            Genre genreIdOld = persistentInventory.getGenreId();
            Genre genreIdNew = inventory.getGenreId();
            Collection<LineItem> lineItemCollectionOld = persistentInventory.getLineItemCollection();
            Collection<LineItem> lineItemCollectionNew = inventory.getLineItemCollection();
            List<String> illegalOrphanMessages = null;
            for (LineItem lineItemCollectionOldLineItem : lineItemCollectionOld) {
                if (!lineItemCollectionNew.contains(lineItemCollectionOldLineItem)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain LineItem " + lineItemCollectionOldLineItem + " since its isbn field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (genreIdNew != null) {
                genreIdNew = em.getReference(genreIdNew.getClass(), genreIdNew.getId());
                inventory.setGenreId(genreIdNew);
            }
            Collection<LineItem> attachedLineItemCollectionNew = new ArrayList<LineItem>();
            for (LineItem lineItemCollectionNewLineItemToAttach : lineItemCollectionNew) {
                lineItemCollectionNewLineItemToAttach = em.getReference(lineItemCollectionNewLineItemToAttach.getClass(), lineItemCollectionNewLineItemToAttach.getId());
                attachedLineItemCollectionNew.add(lineItemCollectionNewLineItemToAttach);
            }
            lineItemCollectionNew = attachedLineItemCollectionNew;
            inventory.setLineItemCollection(lineItemCollectionNew);
            inventory = em.merge(inventory);
            if (genreIdOld != null && !genreIdOld.equals(genreIdNew)) {
                genreIdOld.getInventoryCollection().remove(inventory);
                genreIdOld = em.merge(genreIdOld);
            }
            if (genreIdNew != null && !genreIdNew.equals(genreIdOld)) {
                genreIdNew.getInventoryCollection().add(inventory);
                genreIdNew = em.merge(genreIdNew);
            }
            for (LineItem lineItemCollectionNewLineItem : lineItemCollectionNew) {
                if (!lineItemCollectionOld.contains(lineItemCollectionNewLineItem)) {
                    Inventory oldIsbnOfLineItemCollectionNewLineItem = lineItemCollectionNewLineItem.getIsbn();
                    lineItemCollectionNewLineItem.setIsbn(inventory);
                    lineItemCollectionNewLineItem = em.merge(lineItemCollectionNewLineItem);
                    if (oldIsbnOfLineItemCollectionNewLineItem != null && !oldIsbnOfLineItemCollectionNewLineItem.equals(inventory)) {
                        oldIsbnOfLineItemCollectionNewLineItem.getLineItemCollection().remove(lineItemCollectionNewLineItem);
                        oldIsbnOfLineItemCollectionNewLineItem = em.merge(oldIsbnOfLineItemCollectionNewLineItem);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = inventory.getIsbn();
                if (findInventory(id) == null) {
                    throw new NonexistentEntityException("The inventory with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void destroy(String id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        
        try {
            utx.begin();
            
            Inventory inventory;
            try {
                inventory = em.getReference(Inventory.class, id);
                inventory.getIsbn();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The inventory with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<LineItem> lineItemCollectionOrphanCheck = inventory.getLineItemCollection();
            for (LineItem lineItemCollectionOrphanCheckLineItem : lineItemCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Inventory (" + inventory + ") cannot be destroyed since the LineItem " + lineItemCollectionOrphanCheckLineItem + " in its lineItemCollection field has a non-nullable isbn field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Genre genreId = inventory.getGenreId();
            if (genreId != null) {
                genreId.getInventoryCollection().remove(inventory);
                genreId = em.merge(genreId);
            }
            em.remove(inventory);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public List<Inventory> findInventoryEntities() {
        return findInventoryEntities(true, -1, -1);
    }

    public List<Inventory> findInventoryEntities(int maxResults, int firstResult) {
        return findInventoryEntities(false, maxResults, firstResult);
    }

    private List<Inventory> findInventoryEntities(boolean all, int maxResults, int firstResult) {
        
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Inventory.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            //em.close();
        }
    }

    public Inventory findInventory(String id) {
        
        try {
            return em.find(Inventory.class, id);
        } finally {
            //em.close();
        }
    }

    public int getInventoryCount() {
        
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Inventory> rt = cq.from(Inventory.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            //em.close();
        }
    }
    
}
