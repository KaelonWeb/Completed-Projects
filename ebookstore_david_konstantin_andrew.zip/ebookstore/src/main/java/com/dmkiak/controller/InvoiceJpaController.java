package com.dmkiak.controller;

import com.dmkiak.beans.Invoice;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.dmkiak.beans.User;
import com.dmkiak.beans.LineItem;
import com.dmkiak.controller.exceptions.NonexistentEntityException;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

/**
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class InvoiceJpaController implements Serializable {
    
    @Resource
    private UserTransaction utx;

    @PersistenceContext
    private EntityManager em;

    public void create(Invoice invoice) throws RollbackFailureException, Exception {
        if (invoice.getLineItemCollection() == null) {
            invoice.setLineItemCollection(new ArrayList<LineItem>());
        }
        
        try {
            utx.begin();
            
            User userId = invoice.getUserId();
            if (userId != null) {
                userId = em.getReference(userId.getClass(), userId.getId());
                invoice.setUserId(userId);
            }
            Collection<LineItem> attachedLineItemCollection = new ArrayList<LineItem>();
            for (LineItem lineItemCollectionLineItemToAttach : invoice.getLineItemCollection()) {
                lineItemCollectionLineItemToAttach = em.getReference(lineItemCollectionLineItemToAttach.getClass(), lineItemCollectionLineItemToAttach.getId());
                attachedLineItemCollection.add(lineItemCollectionLineItemToAttach);
            }
            invoice.setLineItemCollection(attachedLineItemCollection);
            em.persist(invoice);
            if (userId != null) {
                userId.getInvoiceCollection().add(invoice);
                userId = em.merge(userId);
            }
            for (LineItem lineItemCollectionLineItem : invoice.getLineItemCollection()) {
                Invoice oldInvoiceIdOfLineItemCollectionLineItem = lineItemCollectionLineItem.getInvoiceId();
                lineItemCollectionLineItem.setInvoiceId(invoice);
                lineItemCollectionLineItem = em.merge(lineItemCollectionLineItem);
                if (oldInvoiceIdOfLineItemCollectionLineItem != null) {
                    oldInvoiceIdOfLineItemCollectionLineItem.getLineItemCollection().remove(lineItemCollectionLineItem);
                    oldInvoiceIdOfLineItemCollectionLineItem = em.merge(oldInvoiceIdOfLineItemCollectionLineItem);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void edit(Invoice invoice) throws NonexistentEntityException, RollbackFailureException, Exception {
        try {
            utx.begin();
            
            Invoice persistentInvoice = em.find(Invoice.class, invoice.getId());
            User userIdOld = persistentInvoice.getUserId();
            User userIdNew = invoice.getUserId();
            Collection<LineItem> lineItemCollectionOld = persistentInvoice.getLineItemCollection();
            Collection<LineItem> lineItemCollectionNew = invoice.getLineItemCollection();
            if (userIdNew != null) {
                userIdNew = em.getReference(userIdNew.getClass(), userIdNew.getId());
                invoice.setUserId(userIdNew);
            }
            Collection<LineItem> attachedLineItemCollectionNew = new ArrayList<LineItem>();
            for (LineItem lineItemCollectionNewLineItemToAttach : lineItemCollectionNew) {
                lineItemCollectionNewLineItemToAttach = em.getReference(lineItemCollectionNewLineItemToAttach.getClass(), lineItemCollectionNewLineItemToAttach.getId());
                attachedLineItemCollectionNew.add(lineItemCollectionNewLineItemToAttach);
            }
            lineItemCollectionNew = attachedLineItemCollectionNew;
            invoice.setLineItemCollection(lineItemCollectionNew);
            invoice = em.merge(invoice);
            if (userIdOld != null && !userIdOld.equals(userIdNew)) {
                userIdOld.getInvoiceCollection().remove(invoice);
                userIdOld = em.merge(userIdOld);
            }
            if (userIdNew != null && !userIdNew.equals(userIdOld)) {
                userIdNew.getInvoiceCollection().add(invoice);
                userIdNew = em.merge(userIdNew);
            }
            for (LineItem lineItemCollectionOldLineItem : lineItemCollectionOld) {
                if (!lineItemCollectionNew.contains(lineItemCollectionOldLineItem)) {
                    lineItemCollectionOldLineItem.setInvoiceId(null);
                    lineItemCollectionOldLineItem = em.merge(lineItemCollectionOldLineItem);
                }
            }
            for (LineItem lineItemCollectionNewLineItem : lineItemCollectionNew) {
                if (!lineItemCollectionOld.contains(lineItemCollectionNewLineItem)) {
                    Invoice oldInvoiceIdOfLineItemCollectionNewLineItem = lineItemCollectionNewLineItem.getInvoiceId();
                    lineItemCollectionNewLineItem.setInvoiceId(invoice);
                    lineItemCollectionNewLineItem = em.merge(lineItemCollectionNewLineItem);
                    if (oldInvoiceIdOfLineItemCollectionNewLineItem != null && !oldInvoiceIdOfLineItemCollectionNewLineItem.equals(invoice)) {
                        oldInvoiceIdOfLineItemCollectionNewLineItem.getLineItemCollection().remove(lineItemCollectionNewLineItem);
                        oldInvoiceIdOfLineItemCollectionNewLineItem = em.merge(oldInvoiceIdOfLineItemCollectionNewLineItem);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = invoice.getId();
                if (findInvoice(id) == null) {
                    throw new NonexistentEntityException("The invoice with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        try {
            utx.begin();
            
            Invoice invoice;
            try {
                invoice = em.getReference(Invoice.class, id);
                invoice.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The invoice with id " + id + " no longer exists.", enfe);
            }
            User userId = invoice.getUserId();
            if (userId != null) {
                userId.getInvoiceCollection().remove(invoice);
                userId = em.merge(userId);
            }
            Collection<LineItem> lineItemCollection = invoice.getLineItemCollection();
            for (LineItem lineItemCollectionLineItem : lineItemCollection) {
                lineItemCollectionLineItem.setInvoiceId(null);
                lineItemCollectionLineItem = em.merge(lineItemCollectionLineItem);
            }
            em.remove(invoice);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public List<Invoice> findInvoiceEntities() {
        return findInvoiceEntities(true, -1, -1);
    }

    public List<Invoice> findInvoiceEntities(int maxResults, int firstResult) {
        return findInvoiceEntities(false, maxResults, firstResult);
    }

    private List<Invoice> findInvoiceEntities(boolean all, int maxResults, int firstResult) {
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Invoice.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            //em.close();
        }
    }

    public Invoice findInvoice(Integer id) {
        try {
            return em.find(Invoice.class, id);
        } finally {
            //em.close();
        }
    }

    public int getInvoiceCount() {
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Invoice> rt = cq.from(Invoice.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            //em.close();
        }
    }
}
