package com.dmkiak.controller;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.dmkiak.beans.User;
import com.dmkiak.beans.Inventory;
import com.dmkiak.beans.Review;
import com.dmkiak.controller.exceptions.NonexistentEntityException;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

/**
 *
 * @author david
 */
@Named
@RequestScoped
public class ReviewJpaController implements Serializable {

    @Resource
    private UserTransaction utx;
    
    @PersistenceContext
    private EntityManager em;

    public void create(Review review) throws RollbackFailureException, Exception {
        try {
            utx.begin();
            
            User userId = review.getUserId();
            if (userId != null) {
                userId = em.getReference(userId.getClass(), userId.getId());
                review.setUserId(userId);
            }
            Inventory isbn = review.getIsbn();
            if (isbn != null) {
                isbn = em.getReference(isbn.getClass(), isbn.getIsbn());
                review.setIsbn(isbn);
            }
            em.persist(review);
            if (userId != null) {
                userId.getReviewCollection().add(review);
                userId = em.merge(userId);
            }
            if (isbn != null) {
                isbn.getReviewCollection().add(review);
                isbn = em.merge(isbn);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void edit(Review review) throws NonexistentEntityException, RollbackFailureException, Exception {
        try {
            utx.begin();
            
            Review persistentReview = em.find(Review.class, review.getId());
            User userIdOld = persistentReview.getUserId();
            User userIdNew = review.getUserId();
            Inventory isbnOld = persistentReview.getIsbn();
            Inventory isbnNew = review.getIsbn();
            if (userIdNew != null) {
                userIdNew = em.getReference(userIdNew.getClass(), userIdNew.getId());
                review.setUserId(userIdNew);
            }
            if (isbnNew != null) {
                isbnNew = em.getReference(isbnNew.getClass(), isbnNew.getIsbn());
                review.setIsbn(isbnNew);
            }
            review = em.merge(review);
            if (userIdOld != null && !userIdOld.equals(userIdNew)) {
                userIdOld.getReviewCollection().remove(review);
                userIdOld = em.merge(userIdOld);
            }
            if (userIdNew != null && !userIdNew.equals(userIdOld)) {
                userIdNew.getReviewCollection().add(review);
                userIdNew = em.merge(userIdNew);
            }
            if (isbnOld != null && !isbnOld.equals(isbnNew)) {
                isbnOld.getReviewCollection().remove(review);
                isbnOld = em.merge(isbnOld);
            }
            if (isbnNew != null && !isbnNew.equals(isbnOld)) {
                isbnNew.getReviewCollection().add(review);
                isbnNew = em.merge(isbnNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = review.getId();
                if (findReview(id) == null) {
                    throw new NonexistentEntityException("The review with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        
        try {
            utx.begin();
            
            Review review;
            try {
                review = em.getReference(Review.class, id);
                review.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The review with id " + id + " no longer exists.", enfe);
            }
            User userId = review.getUserId();
            if (userId != null) {
                userId.getReviewCollection().remove(review);
                userId = em.merge(userId);
            }
            Inventory isbn = review.getIsbn();
            if (isbn != null) {
                isbn.getReviewCollection().remove(review);
                isbn = em.merge(isbn);
            }
            em.remove(review);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public List<Review> findReviewEntities() {
        return findReviewEntities(true, -1, -1);
    }

    public List<Review> findReviewEntities(int maxResults, int firstResult) {
        return findReviewEntities(false, maxResults, firstResult);
    }

    private List<Review> findReviewEntities(boolean all, int maxResults, int firstResult) {
        
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Review.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            //em.close();
        }
    }

    public Review findReview(Integer id) {
        
        try {
            return em.find(Review.class, id);
        } finally {
            //em.close();
        }
    }

    public int getReviewCount() {
        
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Review> rt = cq.from(Review.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            //em.close();
        }
    }
    
}
