/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dmkiak.controller;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.dmkiak.beans.Inventory;
import com.dmkiak.beans.Invoice;
import com.dmkiak.beans.LineItem;
import com.dmkiak.controller.exceptions.NonexistentEntityException;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

/**
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class LineItemJpaController implements Serializable {
    
    @Resource
    private UserTransaction utx;

    @PersistenceContext
    private EntityManager em;

    public void create(LineItem lineItem) throws RollbackFailureException, Exception {
        try {
            utx.begin();

            Inventory isbn = lineItem.getIsbn();
            if (isbn != null) {
                isbn = em.getReference(isbn.getClass(), isbn.getIsbn());
                lineItem.setIsbn(isbn);
            }
            Invoice invoiceId = lineItem.getInvoiceId();
            if (invoiceId != null) {
                invoiceId = em.getReference(invoiceId.getClass(), invoiceId.getId());
                lineItem.setInvoiceId(invoiceId);
            }
            em.persist(lineItem);
            if (isbn != null) {
                isbn.getLineItemCollection().add(lineItem);
                isbn = em.merge(isbn);
            }
            if (invoiceId != null) {
                invoiceId.getLineItemCollection().add(lineItem);
                invoiceId = em.merge(invoiceId);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void edit(LineItem lineItem) throws NonexistentEntityException, RollbackFailureException, Exception {
        try {
            utx.begin();
            
            LineItem persistentLineItem = em.find(LineItem.class, lineItem.getId());
            Inventory isbnOld = persistentLineItem.getIsbn();
            Inventory isbnNew = lineItem.getIsbn();
            Invoice invoiceIdOld = persistentLineItem.getInvoiceId();
            Invoice invoiceIdNew = lineItem.getInvoiceId();
            if (isbnNew != null) {
                isbnNew = em.getReference(isbnNew.getClass(), isbnNew.getIsbn());
                lineItem.setIsbn(isbnNew);
            }
            if (invoiceIdNew != null) {
                invoiceIdNew = em.getReference(invoiceIdNew.getClass(), invoiceIdNew.getId());
                lineItem.setInvoiceId(invoiceIdNew);
            }
            lineItem = em.merge(lineItem);
            if (isbnOld != null && !isbnOld.equals(isbnNew)) {
                isbnOld.getLineItemCollection().remove(lineItem);
                isbnOld = em.merge(isbnOld);
            }
            if (isbnNew != null && !isbnNew.equals(isbnOld)) {
                isbnNew.getLineItemCollection().add(lineItem);
                isbnNew = em.merge(isbnNew);
            }
            if (invoiceIdOld != null && !invoiceIdOld.equals(invoiceIdNew)) {
                invoiceIdOld.getLineItemCollection().remove(lineItem);
                invoiceIdOld = em.merge(invoiceIdOld);
            }
            if (invoiceIdNew != null && !invoiceIdNew.equals(invoiceIdOld)) {
                invoiceIdNew.getLineItemCollection().add(lineItem);
                invoiceIdNew = em.merge(invoiceIdNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = lineItem.getId();
                if (findLineItem(id) == null) {
                    throw new NonexistentEntityException("The lineItem with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        try {
            utx.begin();
            
            LineItem lineItem;
            try {
                lineItem = em.getReference(LineItem.class, id);
                lineItem.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The lineItem with id " + id + " no longer exists.", enfe);
            }
            Inventory isbn = lineItem.getIsbn();
            if (isbn != null) {
                isbn.getLineItemCollection().remove(lineItem);
                isbn = em.merge(isbn);
            }
            Invoice invoiceId = lineItem.getInvoiceId();
            if (invoiceId != null) {
                invoiceId.getLineItemCollection().remove(lineItem);
                invoiceId = em.merge(invoiceId);
            }
            em.remove(lineItem);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public List<LineItem> findLineItemEntities() {
        return findLineItemEntities(true, -1, -1);
    }

    public List<LineItem> findLineItemEntities(int maxResults, int firstResult) {
        return findLineItemEntities(false, maxResults, firstResult);
    }

    private List<LineItem> findLineItemEntities(boolean all, int maxResults, int firstResult) {
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(LineItem.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            //em.close();
        }
    }

    public LineItem findLineItem(Integer id) {
        try {
            return em.find(LineItem.class, id);
        } finally {
            //em.close();
        }
    }

    public int getLineItemCount() {
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<LineItem> rt = cq.from(LineItem.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            //em.close();
        }
    }
    
}
