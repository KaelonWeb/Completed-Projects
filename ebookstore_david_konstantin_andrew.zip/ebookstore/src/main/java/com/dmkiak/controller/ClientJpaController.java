package com.dmkiak.controller;

import com.dmkiak.beans.Client;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.dmkiak.beans.State;
import com.dmkiak.beans.Title;
import com.dmkiak.beans.User;
import com.dmkiak.controller.exceptions.IllegalOrphanException;
import com.dmkiak.controller.exceptions.NonexistentEntityException;
import com.dmkiak.controller.exceptions.PreexistingEntityException;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

/**
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class ClientJpaController implements Serializable {
    
    @Resource
    private UserTransaction utx;

    @PersistenceContext
    private EntityManager em;

    public void create(Client client) throws IllegalOrphanException, PreexistingEntityException, RollbackFailureException, Exception {
        List<String> illegalOrphanMessages = null;
        User userOrphanCheck = client.getUser();
        if (userOrphanCheck != null) {
            Client oldClientOfUser = userOrphanCheck.getClient();
            if (oldClientOfUser != null) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("The User " + userOrphanCheck + " already has an item of type Client whose user column cannot be null. Please make another selection for the user field.");
            }
        }
        if (illegalOrphanMessages != null) {
            throw new IllegalOrphanException(illegalOrphanMessages);
        }
        
        try {
            utx.begin();
            
            State stateId = client.getStateId();
            if (stateId != null) {
                stateId = em.getReference(stateId.getClass(), stateId.getId());
                client.setStateId(stateId);
            }
            Title titleId = client.getTitleId();
            if (titleId != null) {
                titleId = em.getReference(titleId.getClass(), titleId.getId());
                client.setTitleId(titleId);
            }
            User user = client.getUser();
            if (user != null) {
                user = em.getReference(user.getClass(), user.getId());
                client.setUser(user);
            }
            em.persist(client);
            if (stateId != null) {
                stateId.getClientCollection().add(client);
                stateId = em.merge(stateId);
            }
            if (titleId != null) {
                titleId.getClientCollection().add(client);
                titleId = em.merge(titleId);
            }
            if (user != null) {
                user.setClient(client);
                user = em.merge(user);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findClient(client.getUserId()) != null) {
                throw new PreexistingEntityException("Client " + client + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void edit(Client client) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        try {
            utx.begin();
            
            Client persistentClient = em.find(Client.class, client.getUserId());
            State stateIdOld = persistentClient.getStateId();
            State stateIdNew = client.getStateId();
            Title titleIdOld = persistentClient.getTitleId();
            Title titleIdNew = client.getTitleId();
            User userOld = persistentClient.getUser();
            User userNew = client.getUser();
            List<String> illegalOrphanMessages = null;
            if (userNew != null && !userNew.equals(userOld)) {
                Client oldClientOfUser = userNew.getClient();
                if (oldClientOfUser != null) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("The User " + userNew + " already has an item of type Client whose user column cannot be null. Please make another selection for the user field.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (stateIdNew != null) {
                stateIdNew = em.getReference(stateIdNew.getClass(), stateIdNew.getId());
                client.setStateId(stateIdNew);
            }
            if (titleIdNew != null) {
                titleIdNew = em.getReference(titleIdNew.getClass(), titleIdNew.getId());
                client.setTitleId(titleIdNew);
            }
            if (userNew != null) {
                userNew = em.getReference(userNew.getClass(), userNew.getId());
                client.setUser(userNew);
            }
            client = em.merge(client);
            if (stateIdOld != null && !stateIdOld.equals(stateIdNew)) {
                stateIdOld.getClientCollection().remove(client);
                stateIdOld = em.merge(stateIdOld);
            }
            if (stateIdNew != null && !stateIdNew.equals(stateIdOld)) {
                stateIdNew.getClientCollection().add(client);
                stateIdNew = em.merge(stateIdNew);
            }
            if (titleIdOld != null && !titleIdOld.equals(titleIdNew)) {
                titleIdOld.getClientCollection().remove(client);
                titleIdOld = em.merge(titleIdOld);
            }
            if (titleIdNew != null && !titleIdNew.equals(titleIdOld)) {
                titleIdNew.getClientCollection().add(client);
                titleIdNew = em.merge(titleIdNew);
            }
            if (userOld != null && !userOld.equals(userNew)) {
                userOld.setClient(null);
                userOld = em.merge(userOld);
            }
            if (userNew != null && !userNew.equals(userOld)) {
                userNew.setClient(client);
                userNew = em.merge(userNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = client.getUserId();
                if (findClient(id) == null) {
                    throw new NonexistentEntityException("The client with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        try {
            utx.begin();
            
            Client client;
            try {
                client = em.getReference(Client.class, id);
                client.getUserId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The client with id " + id + " no longer exists.", enfe);
            }
            State stateId = client.getStateId();
            if (stateId != null) {
                stateId.getClientCollection().remove(client);
                stateId = em.merge(stateId);
            }
            Title titleId = client.getTitleId();
            if (titleId != null) {
                titleId.getClientCollection().remove(client);
                titleId = em.merge(titleId);
            }
            User user = client.getUser();
            if (user != null) {
                user.setClient(null);
                user = em.merge(user);
            }
            em.remove(client);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                //em.close();
            }
        }
    }

    public List<Client> findClientEntities() {
        return findClientEntities(true, -1, -1);
    }

    public List<Client> findClientEntities(int maxResults, int firstResult) {
        return findClientEntities(false, maxResults, firstResult);
    }

    private List<Client> findClientEntities(boolean all, int maxResults, int firstResult) { 
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Client.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            //em.close();
        }
    }

    public Client findClient(Integer id) {     
        try {
            return em.find(Client.class, id);
        } finally {
            //em.close();
        }
    }

    public int getClientCount() {
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Client> rt = cq.from(Client.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            //em.close();
        }
    }
}
