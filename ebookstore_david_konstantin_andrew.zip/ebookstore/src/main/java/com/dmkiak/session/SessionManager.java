package com.dmkiak.session;

import com.dmkiak.beans.User;
import com.dmkiak.cart.Cart;
import com.dmkiak.config.PropertyManager;
import java.io.IOException;
import java.math.BigDecimal;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import org.apache.log4j.Logger;

/**
 * Session Manager
 *
 * @author David Maignan <davidmaignan@gmail.com>
 */
@Named
@RequestScoped
public class SessionManager {    
    @Inject
    PropertyManager propertyManager;
    
    /**
     * Set user
     * @param user
     * @return true on success
     */
    public boolean setUser(User user) {
        try{
            FacesContext context = FacesContext.getCurrentInstance();

            context = FacesContext.getCurrentInstance();
            context.getExternalContext().getSessionMap().put("user", user);
        }catch(Exception ex){
            return false;
        }
        
        return true;
    }
    
    /**
     * Get user from session
     * @return User
     */
    public User getUser(){
        User user = null;
        
        FacesContext context = FacesContext.getCurrentInstance();
        
        if(context.getExternalContext().getSessionMap().containsKey("user") && 
                context.getExternalContext().getSessionMap().get("user") instanceof User){
            user = (User) context.getExternalContext().getSessionMap().get("user");
        }
        
        return user;
    }
    
    /**
     * Get cart from session
     * @return 
     */
    public Cart getCart() throws IOException {
        Cart cart = null;
        
        FacesContext context = FacesContext.getCurrentInstance();
        
        if(context.getExternalContext().getSessionMap().get("cart") instanceof Cart){
            cart = (Cart) context.getExternalContext().getSessionMap().get("cart");
        }else{
            cart = new Cart();
            cart.setPst(new BigDecimal(propertyManager.getProperty("PST")));
            cart.setGst(new BigDecimal(propertyManager.getProperty("GST")));
        }
        
        return cart;
    }
    
    /**
     * Empty cart 
     */
    public void emptyCart() throws IOException{
        Cart cart = getCart();
        
        cart.removeAll();
        
        setCart(cart);
    }
    
    /**
     * Set cart to session
     * @param cart
     * @return 
     */
    public boolean setCart(Cart cart) {
        FacesContext context = FacesContext.getCurrentInstance();
        
        context.getExternalContext().getSessionMap().put("cart", cart);
        
        return true;
    }
    
    /**
     * Set cart to session
     * 
     * @return 
     */
    public boolean setCart() throws IOException {
        FacesContext context = FacesContext.getCurrentInstance();
        
        Cart cart = getCart();
        
        context.getExternalContext().getSessionMap().put("cart", new Cart());
        
        return true;
    }
    
    /**
     * Destroy session
     */
    public void destroySession() {
        FacesContext.getCurrentInstance().getExternalContext()
                .invalidateSession();
    }
}
