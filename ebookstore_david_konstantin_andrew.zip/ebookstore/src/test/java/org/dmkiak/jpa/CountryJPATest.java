package org.dmkiak.jpa;

import com.dmkiak.beans.Country;
import com.dmkiak.beans.Inventory;
import com.dmkiak.controller.exceptions.RollbackFailureException;
import com.dmkiak.cart.Cart;
import com.dmkiak.config.PropertyManager;
import com.dmkiak.controller.ReviewJpaController;
import com.dmkiak.cookie.CookieManager;
import com.dmkiak.report.TopClient;
import com.dmkiak.session.SessionManager;
import java.io.File;
import org.jboss.arquillian.junit.Arquillian;
import org.junit.Test;
import org.junit.runner.RunWith;
import javax.annotation.Resource;
import javax.inject.Inject;
import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.List;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.maven.Maven;
import org.junit.Assert;

/**
 *
 * @author david
 */
@RunWith(Arquillian.class)
public class CountryJPATest {

    @Inject
    private CountryJPA countryJPA;

    @Resource(name = "java:app/jdbc/ebookstore")
    private DataSource ds;
    
    @Deployment
    public static WebArchive deploy() {

        // Use an alternative to the JUnit assert library called AssertJ
        // Need to reference MySQL driver as it is not part of either
        // embedded or remote TomEE
        final File[] dependencies = Maven
                .resolver()
                .loadPomFromFile("pom.xml")
                .resolve("mysql:mysql-connector-java",
                        "org.assertj:assertj-core").withoutTransitivity()
                .asFile();

        // For testing Arquillian prefers a resources.xml file over a
        // context.xml
        // Actual file name is resources-mysql-ds.xml in the test/resources
        // folder
        // The SQL script to create the database is also in this folder
        final WebArchive webArchive = ShrinkWrap.create(WebArchive.class, "test.war")
                .setWebXML(new File("src/main/webapp/WEB-INF/web.xml"))
                .addPackage(CookieManager.class.getPackage())
                .addPackage(SessionManager.class.getPackage())
                .addPackage(PropertyManager.class.getPackage())
                .addPackage(InventoryJPA.class.getPackage())
                .addPackage(TopClient.class.getPackage())
                .addPackage(RollbackFailureException.class.getPackage())
                .addPackage(ReviewJpaController.class.getPackage())
                .addPackage(Inventory.class.getPackage())
                .addPackage(Cart.class.getPackage())
                .addPackage(CountryJPA.class.getPackage())
                .addPackage(RollbackFailureException.class.getPackage())
                .addPackage(Country.class.getPackage())
                .addPackage(TopClient.class.getPackage())
                .addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml")
                .addAsWebInfResource(new File("src/main/setup/glassfish-resources.xml"), "glassfish-resources.xml")
                .addAsResource(new File("src/main/resources/META-INF/persistence.xml"), "META-INF/persistence.xml")
                .addAsResource(new File("src/main/webapp/WEB-INF/schema.sql"))
                .addAsResource(new File("src/main/webapp/WEB-INF/beans.xml"))
                .addAsLibraries(dependencies);

        return webArchive;
    }
    
    @Test
    public void testGetAll() throws SQLException {
        List<Country> list = countryJPA.getAll();
        Assert.assertEquals(1, list.size());
    }
}
