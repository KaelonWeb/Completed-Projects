/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.AndrewKersys.DOM;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Andrew
 */
public class DOMSearchXML {
    
    private Document doc = null;
    private String xmlName = null;
    private String xsdName = null;
    private StringBuilder xmlString = null;
    private XPath xpath = null;

    /**
     *
     * @param xmlName
     * @param xsdName
     * @param xmlString
     */
    public DOMSearchXML(String xmlName, String xsdName, StringBuilder xmlString) {
        this.xmlName = xmlName;
        this.xsdName = xsdName;
        this.xmlString = xmlString;

        XPathFactory factory = XPathFactory.newInstance();
        xpath = factory.newXPath();
    }
    
    private boolean readDocument() {

        boolean retVal = false;
        try {
            // Step 1: create a DocumentBuilderFactory
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            // Step 2: create a DocumentBuilder
            DocumentBuilder db;
            db = dbf.newDocumentBuilder();
            // Step 3: parse the input file to get a Document object
            doc = db.parse(new File(xmlName));
            retVal = true;
        } catch (ParserConfigurationException ex) {
            xmlString.append("\nParserConfiguration error because ");
            xmlString.append(ex.getMessage());
        } catch (SAXException ex) {
            xmlString.append("\n").append(xmlName).append(" cannot be parsed because ");
            xmlString.append(ex.getMessage());
        } catch (IOException ex) {
            xmlString.append("\nI/O Exception because");
            xmlString.append(ex.getMessage());
        }
        return retVal;
    }
    
 public void findDirector(String theDirector) {
        ArrayList<String> result = new ArrayList<>();
        NodeList movies = doc.getElementsByTagName("movie");
        for (int i = 0; i < movies.getLength(); i++) {
            boolean foundDirector = false;
            Element movie = (Element) movies.item(i);
            NodeList directors = movie.getElementsByTagName("directors");
            for (int ii = 0; ii < directors.getLength(); ii++) {
                Element director = (Element) directors.item(ii);
                NodeList director2 = director.getElementsByTagName("director");
                for (int iii = 0; iii < director2.getLength(); iii++) {
                    Element star = (Element) director2.item(iii);
                    NodeList children = star.getChildNodes();
                    StringBuilder sb = new StringBuilder();
                    for (int k = 0; k < children.getLength(); k++) {
                        Node child = children.item(k);
                        if (child.getNodeType() == Node.TEXT_NODE) {
                            sb.append(child.getNodeValue());
                        }
                    }
                    if (sb.toString().equals(theDirector)) {
                        foundDirector = true;
                        break;
                    }
                }
                if (foundDirector) {
                    NodeList titles = movie.getElementsByTagName("title");
                    NodeList release = movie.getElementsByTagName("release");
                    NodeList actors = movie.getElementsByTagName("aname");
                    for (int j = 0; j < titles.getLength(); j++) {
                        result.add("Title : " + getText(titles.item(j)));
                        for (int k = 0; k < actors.getLength(); k++) {
                         result.add("Actor/Actrice: " + getText(actors.item(k)));
                        }
                         for (int k = 0; k < directors.getLength(); k++) {
                         result.add("Director : " + getText(directors.item(k)));
                        }
                         result.add("Release : " + getText(release.item(j)));        
                    }
                }
            }
        }
        for (String result1 : result) {
            xmlString.append(result1).append("\n");
        }
    }
    
//  public void findTitle(String theTitle) {
//        ArrayList<String> result = new ArrayList<>();
//        NodeList movies = doc.getElementsByTagName("movie");
//        for (int i = 0; i < movies.getLength(); i++) {
//            boolean foundTitle = false;
//            Element movie = (Element) movies.item(i);
//            NodeList starring = movie.getElementsByTagName("t");
//            for (int ii = 0; ii < starring.getLength(); ii++) {
//                Element actor = (Element) starring.item(ii);
//                NodeList actors = actor.getElementsByTagName("director");
//                for (int iii = 0; iii < actors.getLength(); iii++) {
//                    Element star = (Element) actors.item(iii);
//                    NodeList children = star.getChildNodes();
//                    StringBuilder sb = new StringBuilder();
//                    for (int k = 0; k < children.getLength(); k++) {
//                        Node child = children.item(k);
//                        if (child.getNodeType() == Node.TEXT_NODE) {
//                            sb.append(child.getNodeValue());
//                        }
//                    }
//                    if (sb.toString().equals(theTitle)) {
//                        foundTitle = true;
//                        break;
//                    }
//                }
//                if (foundTitle) {
//                    NodeList titles = movie.getElementsByTagName("title");
//                    NodeList prepurchase = movie.getElementsByTagName("prepurchase");
//                    NodeList rating = movie.getElementsByTagName("rating");
//                    NodeList mtime = movie.getElementsByTagName("title");
//                    NodeList directors = movie.getElementsByTagName("director");
//                    NodeList release = movie.getElementsByTagName("release");
//                    for (int j = 0; j < titles.getLength(); j++) {
//                        result.add("Title : " + getText(titles.item(j)));
//                        for (int k = 0; k < actors.getLength(); k++) {
//                         result.add("Actor/Actrice: " + getText(actors.item(k)));
//                        }
//                         for (int k = 0; k < directors.getLength(); k++) {
//                         result.add("Director : " + getText(directors.item(k)));
//                        }
//                         result.add("Release : " + getText(release.item(j)));        
//                    }
//                }
//            }
//        }
//        for (String result1 : result) {
//            xmlString.append(result1).append("\n");
//        }
//    }
 
    public void findActor(String theActor) {
        ArrayList<String> result = new ArrayList<>();
        NodeList movies = doc.getElementsByTagName("movie");
        for (int i = 0; i < movies.getLength(); i++) {
            boolean foundActor = false;
            Element movie = (Element) movies.item(i);
            NodeList starring = movie.getElementsByTagName("actors");
            for (int ii = 0; ii < starring.getLength(); ii++) {
                Element actor = (Element) starring.item(ii);
                NodeList actors = actor.getElementsByTagName("aname");
                for (int iii = 0; iii < actors.getLength(); iii++) {
                    Element star = (Element) actors.item(iii);
                    NodeList children = star.getChildNodes();
                    StringBuilder sb = new StringBuilder();
                    for (int k = 0; k < children.getLength(); k++) {
                        Node child = children.item(k);
                        if (child.getNodeType() == Node.TEXT_NODE) {
                            sb.append(child.getNodeValue());
                        }
                    }
                    if (sb.toString().equals(theActor)) {
                        foundActor = true;
                        break;
                    }
                }
                if (foundActor) {
                    NodeList titles = movie.getElementsByTagName("title");
                    NodeList directors = movie.getElementsByTagName("director");
                    NodeList release = movie.getElementsByTagName("release");
                    for (int j = 0; j < titles.getLength(); j++) {
                        result.add("Title : " + getText(titles.item(j)));
                        for (int k = 0; k < actors.getLength(); k++) {
                         result.add("Actor/Actrice: " + getText(actors.item(k)));
                        }
                         for (int k = 0; k < directors.getLength(); k++) {
                         result.add("Director : " + getText(directors.item(k)));
                        }
                         result.add("Release : " + getText(release.item(j)));        
                    }
                }
            }
        }
        for (String result1 : result) {
            xmlString.append(result1).append("\n");
        }
    }

    /**
     *
     * @param node
     * @return
     */
    private String getText(Node node) {
        StringBuilder result = new StringBuilder();
        if (!node.hasChildNodes()) {
            return "";
        }
        NodeList list = node.getChildNodes();
        for (int i = 0; i < list.getLength(); i++) {
            Node subnode = list.item(i);
            if (subnode.getNodeType() == Node.TEXT_NODE) {
                result.append(subnode.getNodeValue());
            } else if (subnode.getNodeType()
                    == Node.CDATA_SECTION_NODE) {
                result.append(subnode.getNodeValue());
            } else if (subnode.getNodeType()
                    == Node.ENTITY_REFERENCE_NODE) {
                // Recurse into the subtree for text
                // (and ignore comments)
                result.append(getText(subnode));
            }
        }
        return result.toString();
    }

    public void visitRecursively(Node node) {

        // get all child nodes
        NodeList list = node.getChildNodes();

        for (int i = 0; i < list.getLength(); i++) {
            // get child node
            Node childNode = list.item(i);
            xmlString.append("Found Node: ").append(childNode.getNodeName()).append(" - with value: ").append(childNode.getNodeValue()).append("\n");

            // visit child node
            visitRecursively(childNode);
        }
    }

    /**
     *
     * @param xpathStr
     */

    public void searchWithXPath(String xpathStr) {
        try {
            XPathExpression expr = xpath.compile(xpathStr);
            Object result = expr.evaluate(doc, XPathConstants.NODESET);
            NodeList nodes = (NodeList) result;
            for (int i = 0; i < nodes.getLength(); i++) {
                xmlString.append(i + 1).append("\n");
                xmlString.append(nodes.item(i).getNodeValue()).append("\n");
            }
        } catch (XPathExpressionException e) {
            // TODO Auto-generated catch block
            xmlString.append("\nXPath Exception");
            xmlString.append(e.getMessage());
        }
    }

    /**
     *
     */
    public void perform() {
        boolean valid = XMLXSDValidator.validate(xmlName, xsdName, xmlString);

        if (valid) {
            readDocument();
            if (doc != null) {
                xmlString.append("\n").append(xmlName).append(" has been successfully read into a DOM object\n");
                findActor("Vince Vaughn");
                //searchWithXPath("//starring[actor='Vince Vaughn']/preceding-sibling::title/text()");
                //searchWithXPath("//starring[actor='Vince Vaughn']/../title/text()");
                //visitRecursively(doc.getFirstChild());
            }
        }
    }
}
