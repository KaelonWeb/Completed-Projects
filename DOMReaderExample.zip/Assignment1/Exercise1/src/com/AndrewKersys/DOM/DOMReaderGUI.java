/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.AndrewKersys.DOM;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.*;

/**
 *
 * @author Andrew
 */
public class DOMReaderGUI extends JFrame {
    private final String xmlFile01 = "movielists.xml";
    private final String xsdFile01 = "movelists.xsd";
    
    private final StringBuilder xmlString;
    private JEditorPane jep;
    
    public DOMReaderGUI() {
        super("DOM");
        xmlString = new StringBuilder();

        initialize();
        processXML();
    }
    
        private void initialize() {

        JPanel displayPanel = new JPanel(new BorderLayout());

        jep = new JEditorPane();
        jep.setEditable(false);
        jep.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 18));

        displayPanel.add(new JScrollPane(jep));

        this.setContentPane(displayPanel);

        this.setTitle("DOM");
        this.setSize(1000, 650);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }
        
        private void processXML() {

        // Only works with AMC xml file
        DOMSearchXML dr = new DOMSearchXML(xmlFile01, xsdFile01, xmlString);

        dr.perform();

        if (xmlString != null && xmlString.length() > 0) {
            jep.setText(xmlString.toString());
            jep.setCaretPosition(1);
        }
    }
        
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                DOMReaderGUI thisClass = new DOMReaderGUI();
                thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                thisClass.setVisible(true);
            }
        });
    }
}
