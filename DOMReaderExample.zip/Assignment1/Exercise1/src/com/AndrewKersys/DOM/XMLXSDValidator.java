package com.AndrewKersys.DOM;

import java.io.File;
import java.io.IOException;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.xml.sax.SAXException;

public class XMLXSDValidator {

    /**
     * 
     * @param xmlName
     * @param xsdName
     * @param xmlString
     * @return 
     */
    public static boolean validate(String xmlName, String xsdName, StringBuilder xmlString) {

        boolean retVal = true;

        try {
            // 1. Lookup a factory for the W3C XML Schema language
            SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");

            // 2. Compile the schema.
            // Here the schema is loaded from a java.io.File, but you could use
            // a java.net.URL or a javax.xml.transform.Source instead.
            File schemaLocation = new File(xsdName);
            Schema schema = factory.newSchema(schemaLocation);

            // 3. Get a validator from the schema.
            Validator validator = schema.newValidator();

            // 4. Parse the document you want to check.
            Source source = new StreamSource(xmlName);

            // 5. Check the document
            validator.validate(source);
            System.out.println(xmlName + " is valid.");
        } catch (SAXException ex) {
            xmlString.append("\n").append(xmlName).append(" is not valid because ");
            xmlString.append("\n").append(ex.getMessage());
            retVal = false;
        } catch (IOException e) {
            xmlString.append("\nI/O Exception");
            xmlString.append("\n").append(e.getMessage());
            retVal = false;
        }
        return retVal;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {

        StringBuilder xmlString = new StringBuilder();
        if (XMLXSDValidator.validate("movielists.xml", "movelists.xsd", xmlString))
            xmlString.append("\nValid");
        else
            xmlString.append("\nInvalid");
        System.out.println(xmlString.toString());
    }
}
